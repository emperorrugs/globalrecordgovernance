export default function Page(){return(<>
<h1>Academy</h1>
<p>Curricula, exams, certification.</p>
</>);}