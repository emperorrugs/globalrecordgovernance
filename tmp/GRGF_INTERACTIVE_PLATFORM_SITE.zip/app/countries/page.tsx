export default function Page(){return(<>
<h1>Countries</h1>
<p>Country packages and scaling.</p>
</>);}