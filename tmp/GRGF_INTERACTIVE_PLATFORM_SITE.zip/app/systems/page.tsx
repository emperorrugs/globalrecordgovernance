export default function Page(){return(<>
<h1>Systems</h1>
<p>Archive, Governance OS, Platforms, Engines.</p>
</>);}