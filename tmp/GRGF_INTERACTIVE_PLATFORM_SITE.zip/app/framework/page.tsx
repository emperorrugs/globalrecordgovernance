export default function Page(){return(<>
<h1>Framework</h1>
<p>Canonical GRGF definition and principles.</p>
</>);}