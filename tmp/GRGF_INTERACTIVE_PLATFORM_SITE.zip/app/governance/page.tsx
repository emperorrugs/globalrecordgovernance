export default function Page(){return(<>
<h1>Governance</h1>
<p>Stewardship, neutrality, succession.</p>
</>);}