export default function Page(){return(<>
<h1>Processes</h1>
<p>Versioning, sealing, localization, certification.</p>
</>);}