export default function Home(){return(<>
<h1>Global Record Governance Framework (GRGF)</h1>
<p>Digital Archive System • Governance Operating System • DPI Platform</p>
<div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(260px,1fr))",gap:16}}>
<div className="card"><h3>Archive</h3><p>Immutable, hash-sealed records.</p></div>
<div className="card"><h3>Governance OS</h3><p>Rules and engines that run GRGF.</p></div>
<div className="card"><h3>Countries</h3><p>Sovereign-safe deployment packages.</p></div>
<div className="card"><h3>Academy</h3><p>Training and certification.</p></div>
</div>
</>);}