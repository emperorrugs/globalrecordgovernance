export default function Page(){return(<>
<h1>Archive</h1>
<p>Authoritative hash-sealed records.</p>
</>);}