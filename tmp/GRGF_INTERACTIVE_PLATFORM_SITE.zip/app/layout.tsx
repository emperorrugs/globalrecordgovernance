import "../styles/globals.css";
export default function RootLayout({children}){
return(<html><body>
<nav>
<a href="/">Home</a>
<a href="/framework">Framework</a>
<a href="/systems">Systems</a>
<a href="/processes">Processes</a>
<a href="/countries">Countries</a>
<a href="/academy">Academy</a>
<a href="/archive">Archive</a>
<a href="/governance">Governance</a>
</nav>
<main style={{maxWidth:1200,margin:"0 auto",padding:24}}>{children}</main>
</body></html>);
}