#!/usr/bin/env bash
set -euo pipefail
echo "Bootstrap placeholder. In cloud, create OUs, apply SCP, enable GuardDuty/Config/CloudTrail/Security Hub."
