import os, json, hashlib, base64, pathlib, time, glob, datetime

STORE_DIR = os.environ.get("STORE_DIR", "../collector/_store")
OUT_DIR = os.environ.get("OUT_DIR", "./_proofs")
pathlib.Path(OUT_DIR).mkdir(parents=True, exist_ok=True)

def b16(b): return b.hex()
def h(b): 
    x=hashlib.sha256(); x.update(b); return x.digest()

def build_merkle(leaves: list[bytes]) -> tuple[bytes, list[list[bytes]]]:
    # Simple binary tree; duplicate last leaf if odd
    if not leaves:
        return b"", []
    layer = [h(l) for l in leaves]
    tree = [layer]
    while len(layer) > 1:
        nxt = []
        for i in range(0, len(layer), 2):
            a = layer[i]
            b = layer[i+1] if i+1 < len(layer) else layer[i]
            nxt.append(h(a + b))
        layer = nxt
        tree.append(layer)
    root = tree[-1][0]
    # Proofs per leaf
    proofs = []
    for idx, _ in enumerate(tree[0]):
        path = []
        i = idx
        for layer in tree[:-1]:
            j = i ^ 1
            sib = layer[j if j < len(layer) else i]
            path.append(sib)
            i //= 2
        proofs.append(path)
    return root, proofs

def main():
    files = sorted(glob.glob(os.path.join(STORE_DIR, "*.json")))[-500:]  # last 500 events
    leaves = []
    for f in files:
        with open(f,"r") as fh:
            obj = json.load(fh)
        leaves.append(bytes.fromhex(obj["leaf_hash"]))

    root, proofs = build_merkle(leaves)
    if not leaves:
        print("No leaves to process"); return

    ts = datetime.datetime.utcnow().isoformat()
    out = {
        "generated_at": ts,
        "merkle_root": base64.b64encode(root).decode(),
        "count": len(leaves),
        "proofs": []
    }
    for i, f in enumerate(files):
        with open(f,"r") as fh:
            obj = json.load(fh)
        out["proofs"].append({
            "event_file": os.path.basename(f),
            "leaf_hash": obj["leaf_hash"],
            "merkle_root": out["merkle_root"],
            "path": [base64.b64encode(p).decode() for p in proofs[i]]
        })

    out_file = os.path.join(OUT_DIR, f"proof_batch_{ts.replace(':','-')}.json")
    with open(out_file, "w") as fh:
        json.dump(out, fh, indent=2)
    print("Wrote", out_file)

if __name__ == "__main__":
    main()
