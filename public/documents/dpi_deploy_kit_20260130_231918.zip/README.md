# DPI Deploy Kit (Fast-Track + Optimum)

This kit gives you a **fast-track deploy** using AWS Copilot on ECS Fargate in ca-central-1 and sets up S3 buckets including a **proofs bucket with Object Lock (COMPLIANCE, 7 years)**.

## How to use
1. Ensure you unzipped the **DPI Pilot Starter** adjacent to this folder as `../dpi_pilot_starter/` so the build step finds services.
2. Install AWS CLI, Docker, and [AWS Copilot](https://aws.github.io/copilot-cli/).
3. Run:
```bash
chmod +x deploy/deploy_fast_track.sh
./deploy/deploy_fast_track.sh
```
This will:
- Create ECR repos and push images (collector, pseudonymization) if the starter repo is present.
- Create S3 buckets (`payload`, `proofs` with Object Lock 7y, and `logs`), block public access, and enable KMS encryption.
- Initialize a Copilot app/env, load the included manifests, and deploy **collector**, **pseudonymization**, and the **proof-builder** job.
