#!/usr/bin/env bash
set -euo pipefail

# ==== CONFIG ====
AWS_REGION="${AWS_REGION:-ca-central-1}"
APP_NAME="${APP_NAME:-dpi-pilot}"
ECR_NS="${ECR_NS:-dpi}"
PROOFS_BUCKET="${PROOFS_BUCKET:-dpi-proofs-$(openssl rand -hex 6)}"
PAYLOAD_BUCKET="${PAYLOAD_BUCKET:-dpi-payload-$(openssl rand -hex 6)}"
LOGS_BUCKET="${LOGS_BUCKET:-dpi-logs-$(openssl rand -hex 6)}"
RETENTION_YEARS="${RETENTION_YEARS:-7}"

echo "Region: $AWS_REGION"
echo "App:    $APP_NAME"

# ==== PREREQS ====
command -v aws >/dev/null || { echo "aws CLI required"; exit 1; }
command -v docker >/dev/null || { echo "docker required"; exit 1; }
command -v copilot >/dev/null || { echo "AWS Copilot required: https://aws.github.io/copilot-cli/"; exit 1; }

ACC=$(aws sts get-caller-identity --query Account --output text)
echo "AWS Account: $ACC"

login_ecr() {
  aws ecr get-login-password --region "$AWS_REGION" | docker login --username AWS --password-stdin "$ACC.dkr.ecr.$AWS_REGION.amazonaws.com"
}

# ==== ECR & IMAGES ====
for SVC in collector pseudonymization; do
  REPO="$ECR_NS/$SVC"
  aws ecr describe-repositories --repository-names "$REPO" --region "$AWS_REGION" >/dev/null 2>&1 || \
    aws ecr create-repository --repository-name "$REPO" --region "$AWS_REGION" >/dev/null
done

login_ecr

build_push() {
  local dir="$1"; local name="$2"
  local repo="$ACC.dkr.ecr.$AWS_REGION.amazonaws.com/$ECR_NS/$name"
  docker build -t "$repo:pilot" "$dir"
  docker push "$repo:pilot"
}
# Expect the starter repo adjacent: ../dpi_pilot_starter/services/*
if [ -d "../dpi_pilot_starter/services/collector" ]; then
  build_push "../dpi_pilot_starter/services/collector" "collector"
  build_push "../dpi_pilot_starter/services/pseudonymization" "pseudonymization"
else
  echo "WARNING: starter repo not found at ../dpi_pilot_starter; skipping docker build."
fi

# ==== S3 BUCKETS (with Object Lock for proofs) ====
create_bucket() {
  local name="$1"; local object_lock="$2"
  if [ "$object_lock" = "true" ]; then
    aws s3api create-bucket --bucket "$name" --region "$AWS_REGION" \
      --object-lock-enabled-for-bucket \
      --create-bucket-configuration LocationConstraint="$AWS_REGION" >/dev/null
    aws s3api put-object-lock-configuration --bucket "$name" \
      --object-lock-configuration "{\"ObjectLockEnabled\":\"Enabled\",\"Rule\":{\"DefaultRetention\":{\"Mode\":\"COMPLIANCE\",\"Years\":$RETENTION_YEARS}}}"
  else
    aws s3api create-bucket --bucket "$name" --region "$AWS_REGION" \
      --create-bucket-configuration LocationConstraint="$AWS_REGION" >/dev/null
  fi
  aws s3api put-public-access-block --bucket "$name" \
    --public-access-block-configuration BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true
  aws s3api put-bucket-encryption --bucket "$name" \
    --server-side-encryption-configuration '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"aws:kms"}}]}'
}

echo "Creating buckets..."
create_bucket "$PROOFS_BUCKET" true
create_bucket "$PAYLOAD_BUCKET" false
create_bucket "$LOGS_BUCKET" false

echo "Buckets:"
echo "  PROOFS : $PROOFS_BUCKET"
echo "  PAYLOAD: $PAYLOAD_BUCKET"
echo "  LOGS   : $LOGS_BUCKET"

# ==== COPILOT APP/ENV ====
copilot app init "$APP_NAME" || true
copilot env init --name prod --region "$AWS_REGION" || true

# ==== COPY MANIFESTS ====
MANIFEST_DIR="$(cd "$(dirname "$0")" && pwd)/../manifests"
cp -R "$MANIFEST_DIR" "./copilot_manifests"
cd copilot_manifests

# Inject bucket and region into env vars file
cat > .env.prod <<EOF
AWS_REGION=$AWS_REGION
PROOFS_BUCKET=$PROOFS_BUCKET
PAYLOAD_BUCKET=$PAYLOAD_BUCKET
LOGS_BUCKET=$LOGS_BUCKET
RETENTION_YEARS=$RETENTION_YEARS
EOF

# ==== DEPLOY SERVICES ====
copilot init --app "$APP_NAME" --name collector --svc "Load Balanced Web Service" --dockerfile /dev/null --port 8000 || true
copilot svc init --name pseudonymization --svc "Backend Service" --dockerfile /dev/null || true
copilot job init --name proof-builder --schedule "rate(1 hour)" --dockerfile /dev/null || true

# Move manifests into Copilot structure
mkdir -p copilot/collector copilot/pseudonymization copilot/proof-builder
cp collector/manifest.yml copilot/collector/manifest.yml
cp pseudonymization/manifest.yml copilot/pseudonymization/manifest.yml
cp proof-builder/manifest.yml copilot/proof-builder/manifest.yml

# Deploy env and services
copilot env deploy --name prod
copilot svc deploy --name pseudonymization --env prod
copilot svc deploy --name collector --env prod
copilot job deploy --name proof-builder --env prod

echo "Done. Check 'copilot svc status' and 'copilot svc show -n collector'."
