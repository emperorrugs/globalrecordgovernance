
GC Submission Pack — Read Me

This package contains:
- GRGF DPI v4 archive (your design files)
- System Architecture & Catalog (PDF)
- Full Pilot Bundle (code & upgrades)
- Solo Quickstart (local demo)
- Value proposition & sector CBA (CSVs)
- Production cost plan (CSVs)

Cover Email (copy/paste)
------------------------
Subject: Turnkey DPI Pilot – GRGF-aligned package for GC review (Canada-only)

Hello [Name],

Please find enclosed our GRGF-aligned Digital Public Infrastructure (DPI) pilot package for Government of Canada review.

Contents (encrypted ZIP to follow):
- v4 design archive
- System Architecture & Catalog (PDF)
- Pilot code bundle (links below)
- Cost & value summary (CSVs)

Integrity verification:
SHA-256 of the enclosed zip: [paste hash]

Highlights
- Canada-only deployment (ca-central-1), encryption at rest, Object Lock (WORM) proofs.
- Hourly Merkle proofs with public verification (no PII).
- Policy-as-code (OPA), live compliance evidence (CICE), optional external anchoring.
- Bilingual GCWeb & WCAG 2.2 AA; PIA/TRA & SA&A hooks ready.

Pilot ask (2–3 weeks):
- Approve a staging account in ca-central-1.
- Nominate 2 low-risk event sources (≥250k events/day combined).
- Provide a contact for SSO/SCIM (or allow admin-only login for the pilot).

Best regards,
[Your Name]
[Title / Program]
[Phone]

Submission Checklist
--------------------
1) Zip this pack with AES-256 password (7-Zip): 
   7z a -tzip -mem=AES256 GC-DPI-Submission.zip <all files>
2) Share the password over a separate channel (phone/SMS).
3) Send hash for integrity (PowerShell): Get-FileHash GC-DPI-Submission.zip -Algorithm SHA256
