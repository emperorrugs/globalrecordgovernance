from fastapi import FastAPI
from pydantic import BaseModel
import hmac, hashlib, os, base64

app = FastAPI(title="DPI Pseudonymization")
SECRET = os.environ.get("TOKEN_SECRET", "replace-me-in-prod").encode("utf-8")

class TokenizeIn(BaseModel):
    identifier: str

class TokenizeOut(BaseModel):
    token: str

def hmac_token(s: str) -> str:
    mac = hmac.new(SECRET, s.encode("utf-8"), hashlib.sha256).digest()
    return base64.urlsafe_b64encode(mac)[:22].decode("utf-8")

@app.post("/tokenize", response_model=TokenizeOut)
def tokenize(inp: TokenizeIn):
    return TokenizeOut(token=hmac_token(inp.identifier))
