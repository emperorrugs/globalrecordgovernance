from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel, Field
from datetime import datetime, timezone
import json, os, hashlib, pathlib
from jsonschema import validate, ValidationError

app = FastAPI(title="DPI Collector")

SCHEMA_PATH = os.environ.get("EVENT_SCHEMA", "../../config/schemas/example.json")
STORE_DIR = os.environ.get("STORE_DIR", "./_store")
pathlib.Path(STORE_DIR).mkdir(parents=True, exist_ok=True)

def canonical_json(obj):
    return json.dumps(obj, separators=(",", ":"), sort_keys=True).encode("utf-8")

def sha256(b: bytes) -> bytes:
    h = hashlib.sha256()
    h.update(b)
    return h.digest()

def hexit(b: bytes) -> str:
    return b.hex()

class EventIn(BaseModel):
    source_id: str
    occurred_at: str = Field(..., description="RFC3339")
    subject_ref: str | None = None
    payload: dict

@app.post("/ingest")
async def ingest(evt: EventIn, request: Request):
    # Basic schema validation
    with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
        schema = json.load(f)
    candidate = {
        "source_id": evt.source_id,
        "occurred_at": evt.occurred_at,
        "subject_ref": evt.subject_ref,
        "payload": evt.payload,
    }
    try:
        validate(candidate, schema)
    except ValidationError as ve:
        raise HTTPException(status_code=422, detail=f"schema error: {ve.message}")

    # Append-only file store (for demo). In cloud, write to S3 and Aurora.
    now = datetime.now(timezone.utc).isoformat()
    canonical = canonical_json(candidate | {"received_at": now})
    leaf_hash = sha256(canonical)

    out = {
        "received_at": now,
        "leaf_hash": hexit(leaf_hash),
        "event": candidate
    }
    fname = f"{now.replace(':','-')}_{out['leaf_hash']}.json"
    with open(os.path.join(STORE_DIR, fname), "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, sort_keys=True)

    return {"status": "ok", "leaf_hash": out["leaf_hash"], "stored": fname}
