# DPI Upgrades – ALL (CICE + Verifiable Credentials + Omission Intelligence)

A) CICE emits compliance attestations as events.  
B) VC issuer/verifier enables selective disclosure.  
C) Omission detector flags expected-but-missing events.

Set `COLLECTOR_URL` to your Collector's /ingest URL.
