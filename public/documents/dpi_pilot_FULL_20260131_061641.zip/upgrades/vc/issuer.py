import argparse, json, os, uuid
from datetime import datetime, timezone
from lib.common import sign_hmac

ISSUER_DID = os.environ.get("VC_ISSUER_DID","did:example:dpi")
KEY = os.environ.get("VC_SIGNING_KEY","replace-me")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--event-hash", required=True)
    ap.add_argument("--subject", required=True)
    ap.add_argument("--claim", action="append", default=[])
    ap.add_argument("--out", default="vc.json")
    args = ap.parse_args()

    claims = {}
    for c in args.claim:
        if "=" in c:
            k,v = c.split("=",1); claims[k]=v
    vc = {
        "@context": ["https://www.w3.org/2018/credentials/v1"],
        "type": ["VerifiableCredential","EventExistenceCredential"],
        "id": f"urn:uuid:{uuid.uuid4()}",
        "issuer": ISSUER_DID,
        "issuanceDate": datetime.now(timezone.utc).isoformat(),
        "credentialSubject": {
            "id": args.subject,
            "event": {"hash": args.event_hash, **claims}
        }
    }
    vc["proof"] = {
        "type":"HMAC-SHA256",
        "created": vc["issuanceDate"],
        "verificationMethod":"env:VC_SIGNING_KEY",
        "jws": sign_hmac(vc, KEY)
    }
    with open(args.out,"w",encoding="utf-8") as f:
        json.dump(vc, f, indent=2, sort_keys=True)
    print("Wrote", args.out)

if __name__ == "__main__":
    main()
