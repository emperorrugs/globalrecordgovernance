import argparse, json, hmac
from lib.common import sign_hmac

KEY = None

def main():
    import os
    global KEY
    KEY = os.environ.get("VC_SIGNING_KEY","replace-me")
    ap = argparse.ArgumentParser()
    ap.add_argument("--vc", required=True)
    args = ap.parse_args()
    with open(args.vc,"r",encoding="utf-8") as f:
        vc = json.load(f)
    sig = vc.get("proof",{}).get("jws")
    expected = sign_hmac({k:vc[k] for k in vc if k!="proof"}, KEY)
    if sig and hmac.compare_digest(sig, expected):
        print("OK: VC signature valid & structure looks good.")
    else:
        print("FAIL: signature mismatch or missing")
        exit(2)

if __name__ == "__main__":
    main()
