import os, json, hmac, hashlib, base64, requests
from datetime import datetime, timezone

COLLECTOR_URL = os.environ.get("COLLECTOR_URL", "http://localhost:8000/ingest")
SHARED_SECRET = os.environ.get("DPI_SHARED_SECRET", "replace-me")

def now_iso():
    return datetime.now(timezone.utc).isoformat()

def post_event(event):
    payload = {
        "source_id": event.get("source_id","upgrade"),
        "occurred_at": event.get("occurred_at", now_iso() ),
        "subject_ref": event.get("subject_ref"),
        "payload": event.get("payload", {})
    }
    r = requests.post(COLLECTOR_URL, json=payload, timeout=10)
    r.raise_for_status()
    return r.json()

def sign_hmac(obj: dict, key: str = SHARED_SECRET):
    msg = json.dumps(obj, separators=(',', ':'), sort_keys=True).encode('utf-8')
    sig = hmac.new(key.encode('utf-8'), msg, hashlib.sha256).digest()
    return base64.urlsafe_b64encode(sig).decode('utf-8').rstrip('=')
