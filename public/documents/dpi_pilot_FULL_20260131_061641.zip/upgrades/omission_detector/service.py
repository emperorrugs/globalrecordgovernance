import argparse, json, os, glob
from datetime import datetime, timezone, timedelta
from lib.common import post_event, now_iso

def parse_time(s): 
    if s is None: return None
    return datetime.fromisoformat(s.replace('Z','+00:00'))

def load_events_from_collector_store(path):
    files = sorted(glob.glob(os.path.join(path, "*.json")))
    events = []
    for f in files:
        try:
            with open(f,"r",encoding="utf-8") as fh:
                obj = json.load(fh)
            ev = obj.get("event",{})
            ev["received_at"] = obj.get("received_at")
            events.append(ev)
        except Exception:
            continue
    return events

def check_rule(rule, events):
    findings = []
    for ev in events:
        if ev.get("payload",{}).get("type") == rule["when"]["type"]:
            t0 = parse_time(ev.get("occurred_at") or ev.get("received_at"))
            if t0 is None: 
                continue
            deadline = t0 + timedelta(hours=rule["expect"]["within_hours"])
            ok = any(
                e.get("payload",{}).get("type") == rule["expect"]["type"] and
                parse_time(e.get("occurred_at") or e.get("received_at")) is not None and
                parse_time(e.get("occurred_at") or e.get("received_at")) <= deadline
                for e in events
            )
            if not ok:
                findings.append({
                    "base_event": ev,
                    "rule": rule["name"],
                    "expected": rule["expect"],
                    "deadline": deadline.isoformat()
                })
    return findings

def emit_omission(f):
    evt = {
        "source_id":"omission-detector",
        "occurred_at": now_iso(),
        "payload":{
            "type":"OMISSION_DETECTED",
            "rule": f["rule"],
            "expected": f["expected"],
            "base_event": {
                "type": f["base_event"]["payload"]["type"],
                "occurred_at": f["base_event"].get("occurred_at")
            },
            "deadline": f["deadline"]
        }
    }
    res = post_event(evt)
    print("OMISSION:", f["rule"], "->", res)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rules", required=True)
    ap.add_argument("--store", default="../services/collector/_store")
    args = ap.parse_args()
    rules = json.loads(open(args.rules,"r",encoding="utf-8").read())
    events = load_events_from_collector_store(args.store)
    for r in rules.get("rules", []):
        findings = check_rule(r, events)
        for f in findings:
            emit_omission(f)

if __name__ == "__main__":
    main()
