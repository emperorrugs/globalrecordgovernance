import argparse, json, os, glob, base64

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--proof-dir", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--log-id", default="dpi-roots-log")
    args = ap.parse_args()

    files = sorted(glob.glob(os.path.join(args.proof_dir, "*.json")))
    leaves = []
    for f in files:
        try:
            obj = json.load(open(f,"r",encoding="utf-8"))
            leaves.append({
                "merkle_root_b64": obj.get("merkle_root"),
                "timestamp_rfc3339": obj.get("generated_at"),
                "metadata": {"batch_count": obj.get("count", 0), "source_file": os.path.basename(f)}
            })
        except Exception:
            pass

    out = {"log_id": args.log_id, "leaves": leaves}
    with open(args.out,"w",encoding="utf-8") as fh:
        json.dump(out, fh, indent=2)
    print(f"Wrote {len(leaves)} leaves to {args.out}")

if __name__ == "__main__":
    main()
