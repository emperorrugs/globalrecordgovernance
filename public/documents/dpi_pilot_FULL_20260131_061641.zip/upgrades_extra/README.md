# Upgrades: External Anchoring (OpenTimestamps) + Transparency Log Export (Trillian)

This add-on gives you:
1) **OpenTimestamps (OTS) anchoring** for your Merkle roots (weekly by default).
2) **Trillian-compatible export** so you can mirror roots into a transparency log.

## 1) OpenTimestamps Anchoring

**What it does:** takes your hourly Merkle roots (from proof builder outputs) and produces OTS requests,
so you can later finalize and publish Bitcoin-backed timestamps.

### How to use
- Install the OTS client on the machine that holds proofs: https://opentimestamps.org
- Put your proof batches in a folder (e.g., `services/proof_builder/_proofs/` as in the starter).
- Run (weekly or on demand):

```bash
python anchoring/collect_roots.py --proof-dir ../services/proof_builder/_proofs --out anchoring/roots.txt
bash anchoring/ots_anchor.sh anchoring/roots.txt
```

This will create `*.ots` files beside `roots.txt`. You can later upgrade proofs with:
```bash
ots upgrade anchoring/roots.txt.ots
```

## 2) Trillian Export

**What it does:** emits a JSON file with entries/leaf data you can feed to a Trillian log or adapter.

Run:
```bash
python transparency/trillian_export.py --proof-dir ../services/proof_builder/_proofs --out transparency/trillian_batch.json
```

Output schema (simplified):
```json
{
  "log_id": "dpi-roots-log",
  "leaves": [
    {"merkle_root_b64": "...", "timestamp_rfc3339": "...", "metadata": {"batch_count":123}}
  ]
}
```
You can adapt this to your Trillian ingestion layer.
