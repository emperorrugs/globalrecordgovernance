import argparse, json, os, glob, base64, datetime

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--proof-dir", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    files = sorted(glob.glob(os.path.join(args.proof_dir, "*.json")))
    roots = []
    for f in files:
        try:
            obj = json.load(open(f,"r",encoding="utf-8"))
            roots.append(obj.get("merkle_root"))
        except Exception:
            pass

    roots = [r for r in roots if r]
    with open(args.out, "w", encoding="utf-8") as out:
        for r in roots:
            out.write(r + "\n")
    print(f"Wrote {len(roots)} roots to {args.out}")

if __name__ == "__main__":
    main()
