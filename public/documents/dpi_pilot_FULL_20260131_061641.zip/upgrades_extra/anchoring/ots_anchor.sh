#!/usr/bin/env bash
set -euo pipefail
ROOTS_FILE="${1:-anchoring/roots.txt}"
if ! command -v ots >/dev/null 2>&1; then
  echo "OpenTimestamps client (ots) not found. Install from https://opentimestamps.org"; exit 1
fi
if [ ! -f "$ROOTS_FILE" ]; then
  echo "Roots file not found: $ROOTS_FILE"; exit 1
fi
# Create a file with newline-separated roots and stamp it
# We stamp the entire file so one OTS file covers many roots
ots stamp "$ROOTS_FILE"
echo "Stamped: ${ROOTS_FILE}.ots"
echo "Later you can run: ots upgrade ${ROOTS_FILE}.ots"
