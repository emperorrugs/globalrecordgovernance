# PowerShell one-shot deploy (see main message for full body)
