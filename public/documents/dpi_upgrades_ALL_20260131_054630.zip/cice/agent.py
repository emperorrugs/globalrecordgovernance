import json
from pathlib import Path
from lib.common import post_event, now_iso

CFG = json.loads(Path("config.json").read_text(encoding="utf-8"))

def emit_attestation(control):
    evt = {
        "source_id": "cice",
        "occurred_at": now_iso(),
        "payload": {
            "type": "CONTROL_ATTESTATION",
            "control_id": control["id"],
            "status": control["status"],
            "evidence": control.get("evidence", {})
        }
    }
    res = post_event(evt)
    print("Emitted:", control["id"], res)

def main():
    for c in CFG.get("controls", []):
        emit_attestation(c)

if __name__ == "__main__":
    main()
