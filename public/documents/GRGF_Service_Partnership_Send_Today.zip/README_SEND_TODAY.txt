Send-Today Package Instructions:
Attach ZIP to emails and send today.
