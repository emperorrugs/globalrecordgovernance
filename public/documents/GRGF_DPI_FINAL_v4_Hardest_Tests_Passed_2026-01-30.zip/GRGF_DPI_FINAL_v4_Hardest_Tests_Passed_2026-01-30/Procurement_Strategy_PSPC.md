# GRGF DPI – Procurement Strategy (PSPC)
## Objective
Enable compliant pilot procurement under Canadian federal rules.

## Pathways
- Innovation pilot
- Phased competitive procurement

## Evaluation Criteria
Security, interoperability, sovereignty, value-for-money.
