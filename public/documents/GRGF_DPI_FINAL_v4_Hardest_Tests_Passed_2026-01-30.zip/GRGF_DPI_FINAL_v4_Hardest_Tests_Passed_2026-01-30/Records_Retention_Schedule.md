# GRGF DPI – Records Retention Schedule
## Principles
Retention aligned with legal, fiscal, and historical value.

## Categories
- Operational Records: 7 years
- Legal/Evidentiary Records: Permanent
- Audit Logs: Minimum 10 years

## Disposition
Controlled, logged, and reviewable.
