# GRGF DPI – Incident Response Plan
## Severity Levels
Low, Medium, High, Critical.

## Response Phases
Detection, containment, eradication, recovery, post-incident review.

## Governance
Incident Oversight Committee with mandatory reporting.
