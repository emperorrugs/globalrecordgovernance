
# GRGF – Public Overview

GRGF is a neutral Digital Public Infrastructure that records institutional actions
and omissions in real time, providing immutable evidence without interpretation.

It supports transparency, accountability, and trust at national and global scale.
