
# GRGF DPI — Oral Defense Briefing
Problem → Solution → Value → Ask
