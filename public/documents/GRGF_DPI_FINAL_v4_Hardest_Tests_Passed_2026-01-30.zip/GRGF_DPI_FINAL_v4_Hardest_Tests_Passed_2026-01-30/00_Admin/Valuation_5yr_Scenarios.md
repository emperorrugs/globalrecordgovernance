
# GRGF DPI — 5-Year Valuation & Inventor Return (USD)

Conservative EV: $960M | Inventor (40%): $384M
Base EV: $2.6B | Inventor (40%): $1.04B
Aggressive EV: $6.24B | Inventor (40%): $2.5B
