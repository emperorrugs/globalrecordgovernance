
# Threat Model (STRIDE)
Analyzes spoofing, tampering, repudiation, information disclosure, denial of service, and elevation of privilege.
Includes risk treatment plan.
