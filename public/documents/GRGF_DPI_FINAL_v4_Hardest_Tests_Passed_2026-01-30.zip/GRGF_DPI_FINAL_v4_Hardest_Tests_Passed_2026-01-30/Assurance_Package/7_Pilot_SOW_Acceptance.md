
# Pilot SOW & Acceptance Criteria
Defines scope, milestones, security/privacy gates, and success metrics.
