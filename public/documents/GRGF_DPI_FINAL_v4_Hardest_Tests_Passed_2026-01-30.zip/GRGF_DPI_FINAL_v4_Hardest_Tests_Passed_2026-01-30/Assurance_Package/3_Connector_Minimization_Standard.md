
# Connector Minimization Standard
Defines mandatory exclusion rules for personal and operational data.
Ensures least-collection-by-default.
