
# Resilience & Disaster Recovery
Defines RTO/RPO, integrity recovery, and offline survivability.
