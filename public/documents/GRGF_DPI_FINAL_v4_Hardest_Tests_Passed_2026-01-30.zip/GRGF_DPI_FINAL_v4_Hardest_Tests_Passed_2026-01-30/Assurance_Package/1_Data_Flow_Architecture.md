
# System Data-Flow Architecture
Describes end-to-end flow from source systems to GRGF custody, retention, access, and disclosure.
Includes minimization, pseudonymization, and boundary controls.
