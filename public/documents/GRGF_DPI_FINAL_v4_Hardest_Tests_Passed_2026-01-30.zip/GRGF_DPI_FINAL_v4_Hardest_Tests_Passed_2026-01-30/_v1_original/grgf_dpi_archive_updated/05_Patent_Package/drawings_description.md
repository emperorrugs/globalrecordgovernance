# Drawings Description

The drawing(s) illustrate the key components of the Global Records & Governance Framework (GRGF).  Under CIPO guidelines, drawings must show every feature of the invention defined by the claims【756158506695095†L225-L235】.  The drawing provided with this application depicts the relationships between the major subsystems and the standards layer.

## Figure 1 – GRGF system architecture

Figure 1 shows a box labelled **“GRGS Standards”** positioned above three horizontally arranged boxes labelled **“RIRS”**, **“RECO”** and **“EAE”**.  Arrows extend from the standards box downwards to each of the three subsystem boxes to indicate that the standards apply to all subsystems.  The components are described as follows:

* **GRGS Standards:** a set of open standards defining data schemas, protocols and governance requirements for GRGF implementations.

* **RIRS (Reality Integrity Recording System):** event capture subsystem that records actions and omissions.

* **RECO (Records Custody Office):** secure storage and custody subsystem that maintains an immutable ledger of records.

* **EAE (Evidentiary Assurance Engine):** audit subsystem that verifies the integrity and completeness of records.

This figure demonstrates how the three subsystems operate under a common standards framework and illustrates the modular nature of the invention.  The drawing has been prepared on white paper with clear line drawings and labels in accordance with CIPO formatting guidelines【756158506695095†L225-L237】.