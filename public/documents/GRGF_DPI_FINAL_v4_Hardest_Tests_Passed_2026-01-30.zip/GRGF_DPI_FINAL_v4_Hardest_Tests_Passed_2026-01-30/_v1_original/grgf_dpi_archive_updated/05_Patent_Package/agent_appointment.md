# Agent Appointment (optional)

Under the Patent Rules, you must appoint a patent agent if the application is filed by someone other than the inventor, if there are multiple inventors and the application is not filed jointly, or if the application has been transferred【756158506695095†L299-L312】.  The appointment can be included in the petition or in a separate document.

**Appointment statement:**

I/we, the applicant(s) for the patent application entitled *Global Records & Governance Framework (GRGF)*, hereby appoint **[Name of patent agent]** of **[agent firm and address]** as our patent agent.  The patent agent is authorized to act on our behalf in all proceedings before the Canadian Intellectual Property Office relating to this application.

**Applicants:**

1. Name: [Applicant 1]   Signature: _______________
2. Name: [Applicant 2]   Signature: _______________

**Date:**  [Date]