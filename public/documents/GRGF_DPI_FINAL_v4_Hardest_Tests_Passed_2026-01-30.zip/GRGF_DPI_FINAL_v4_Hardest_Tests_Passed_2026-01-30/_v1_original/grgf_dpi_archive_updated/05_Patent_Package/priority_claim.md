# Priority Claim (optional)

If you have previously filed an application for the same invention in Canada or another country, you may claim priority to that earlier filing【756158506695095†L318-L337】.

**Statement of priority:**

The applicant claims priority to the following earlier application:

* **Application number:**  [Number]
* **Country or office of filing:**  [Country/office]
* **Filing date:**  [Date]

If the earlier application was not filed in Canada, attach a certified copy of the earlier application or provide access through WIPO’s Digital Access Service by supplying the access code【756158506695095†L318-L337】.

**Date:**  [Date]

**Signature:**  [Signature of applicant or authorized representative]