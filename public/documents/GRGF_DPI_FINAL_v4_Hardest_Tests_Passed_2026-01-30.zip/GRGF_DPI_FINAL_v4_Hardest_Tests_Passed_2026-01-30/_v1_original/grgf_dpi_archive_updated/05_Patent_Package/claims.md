# Claims

Each claim defines a separate aspect of the invention.  Claims should be clear, complete and supported by the description【756158506695095†L155-L165】.  They are presented below in single‑sentence format using the transition term **“comprising”**, which signals that additional elements may also be present【756158506695095†L169-L187】.

1. **An apparatus for capturing and maintaining an immutable record of institutional events**, comprising:

  (a) an **event capture subsystem** configured to record, in real time, actions and omissions occurring within one or more institutional systems;

  (b) a **custody storage subsystem** configured to securely store records produced by the event capture subsystem, the custody storage subsystem applying cryptographic seals and maintaining a tamper‑evident chain of custody; and

  (c) a **verification subsystem** configured to audit and verify the integrity, completeness and authenticity of records stored in the custody storage subsystem;

  wherein the event capture subsystem comprises non‑intrusive observer modules integrated with existing transactional systems via unidirectional data flows to minimize performance impact【508747426460165†L1666-L1671】, and wherein the apparatus ensures custodial independence by separating the custody storage subsystem from the systems generating the records【77671785459166†L36-L107】.

2. **The apparatus of claim 1**, wherein the event capture subsystem produces structured event records containing metadata selected from the group consisting of timestamps, pseudonymous actor identifiers, event types, context identifiers and unique record identifiers.

3. **The apparatus of claim 1**, wherein the custody storage subsystem stores records in an append‑only ledger and links each record to the preceding record using cryptographic hash values.

4. **The apparatus of claim 1**, wherein the verification subsystem comprises an evidentiary assurance engine that automatically audits the ledger, generates proofs of non‑tampering and completeness, and outputs audit reports suitable for judicial proceedings.

5. **The apparatus of any one of claims 1 to 4**, wherein the apparatus implements an open standard schema defined by a governance framework (GRGS) to ensure interoperability across deployments.

6. **A method of providing a neutral evidence layer for institutional processes**, comprising the steps of:

  (a) **capturing** actions and omissions in real time using observer modules integrated with institutional systems;

  (b) **storing** the captured records in a secure custody storage subsystem that applies cryptographic seals and maintains an immutable chain of custody;

  (c) **verifying** the integrity and completeness of stored records using an audit subsystem that generates audit proofs; and

  (d) **providing** access to stored records via standardized interfaces to authorized parties for audit, investigative or judicial purposes;

  wherein the method ensures that only metadata necessary for accountability is captured and that personal data is pseudonymized【508747426460165†L1666-L1671】.

7. **The method of claim 6**, wherein capturing actions and omissions comprises detecting expected actions that do not occur within a predefined time interval and recording such omissions as events.

8. **The method of claim 6**, wherein storing captured records comprises encoding each record with a cryptographic hash and linking each record to a preceding record to form a tamper‑evident chain.

9. **The method of claim 6**, wherein verifying the integrity of stored records comprises recalculating hash values across the chain of custody and generating a proof of non‑tampering.

10. **A system according to any one of claims 1 to 9** deployed within a digital public infrastructure for public health, finance, justice or other sector, wherein the system reduces record loss and fraud and improves institutional accountability【584430089377844†L84-L140】.