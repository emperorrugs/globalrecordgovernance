# Common Representative Appointment (optional)

If there is more than one applicant, the applicants may appoint a common representative to act on their behalf【756158506695095†L284-L299】.

**Appointment statement:**

We, the undersigned applicants for the patent application entitled *Global Records & Governance Framework (GRGF)*, appoint **[Name of common representative]** of **[address]** as our common representative in accordance with the Patent Rules.  The common representative is authorized to represent all applicants in matters relating to this application.

**Applicants:**

1. Name: [Applicant 1]   Signature: _______________
2. Name: [Applicant 2]   Signature: _______________
3. Name: [Applicant 3]   Signature: _______________

**Date:**  [Date]