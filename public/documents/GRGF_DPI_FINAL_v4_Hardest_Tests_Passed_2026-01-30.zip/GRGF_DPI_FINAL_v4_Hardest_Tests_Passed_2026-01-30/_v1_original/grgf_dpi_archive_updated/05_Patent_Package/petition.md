# Petition for Grant of Patent

This petition is your formal request for a patent from the Canadian Intellectual Property Office (CIPO).  It must include the title of the invention and the full names and addresses of the applicant(s) and inventor(s)【756158506695095†L64-L74】.  The statement of entitlement may be included here or in a separate document【756158506695095†L86-L99】.

**Title of invention:** *Global Records & Governance Framework (GRGF)*

**Applicant(s):**

- **Name:**  [Full legal name of applicant]
- **Address:**  [Complete postal address]

**Inventor(s):**

- **Name:**  [Full legal name of inventor]
- **Address:**  [Complete postal address]

**Statement of entitlement:**

The applicant is the sole inventor and is entitled to apply for a patent for the invention described herein【756158506695095†L86-L99】.  If there are multiple inventors, insert a statement indicating that all applicants are inventors and are jointly entitled to apply.

**Small entity declaration (optional):**

If you wish to benefit from reduced fees, declare that you meet the small entity conditions (fewer than 100 employees or a university)【756158506695095†L255-L278】.  Include a statement referencing subsection 44(2) of the Patent Rules and sign it or have your patent agent sign on your behalf.

**Agent appointment (optional):**

If you appoint a patent agent, identify the agent and their address here or in a separate document【756158506695095†L299-L312】.

**Common representative (optional):**

If there are multiple applicants, you may appoint a common representative from among the applicants【756158506695095†L284-L299】.  Provide the representative’s name and address.

**Priority claim (optional):**

If you are claiming priority from an earlier application, provide the application number, country, filing date and, if necessary, access code for the previous filing【756158506695095†L318-L337】.

**Date:**  [Date of submission]

**Signature:**  [Signature of applicant or authorized representative]