# Small Entity Declaration (optional)

Under the Patent Rules, small entities (organizations with fewer than 100 employees or universities) may pay reduced fees【756158506695095†L255-L278】.  To qualify, submit a declaration signed by the applicant or their patent agent.

**Declaration:**

I, [Name of applicant or authorized representative], declare that the applicant(s) for the patent application entitled *Global Records & Governance Framework (GRGF)* qualify as a small entity under subsection 44(2) of the Patent Rules.  The applicant(s) have fewer than 100 employees [or is a university] and therefore are entitled to pay fees at the small entity rate.  I understand that this declaration applies to all applicants and remains in effect for the duration of the application.

**Date:**  [Date]

**Signature:**  [Signature of applicant or authorized representative]