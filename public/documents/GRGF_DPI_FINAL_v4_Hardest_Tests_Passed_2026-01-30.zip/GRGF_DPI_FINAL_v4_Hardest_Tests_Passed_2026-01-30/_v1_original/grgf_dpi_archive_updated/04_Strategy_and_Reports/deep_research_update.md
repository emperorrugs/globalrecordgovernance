# Additional DPI Research and Best Practices (2026)

This briefing supplements the existing GRGF strategy by summarising
recent research and policy guidance on **digital public infrastructure (DPI)**.
It highlights why DPI is essential for inclusive economic and social
development, summarises adoption patterns across OECD countries, and
identifies key lessons for GRGF implementation and advocacy.

## Why DPI Matters

The 50‑in‑5 campaign—an international initiative to help 50 countries
design, launch and scale DPI components within five years—notes that
DPI comprises a **secure and interoperable network of components**
including digital payments, identity systems and data exchange【613189595351783†L44-L50】.
It is essential for participation in markets and society in a digital era【613189595351783†L44-L50】.
By digitising and modernising services with DPI, governments can serve
people more swiftly and efficiently; however public institutions have a
crucial role to ensure that DPI remains **inclusive, foundational,
interoperable and publicly accountable**【613189595351783†L52-L59】.
DPI that is built with open, adaptable solutions and strong governance
can promote innovation, bolster local entrepreneurship, and extend
services to underserved groups such as women and youth【613189595351783†L61-L67】.
Without coordinated action, countries risk being locked into costly
digital monopolies and creating fragmented ecosystems【613189595351783†L69-L73】.

## Adoption Patterns and Enablers

A recent **OECD survey on digital government** examined DPI across
33 OECD countries.  It identified six key components—**digital identity,
digital payments, data‑sharing systems, digital post, digital
notifications and base registries**—and noted that governments also
provide underlying enablers such as open‑source and interoperability
frameworks, API standards and metadata standards【282798810985535†L6028-L6048】.
Adoption varies: data‑sharing systems are present in 85% of countries,
digital identities in 73%, base registries in 64%, digital post in 58%,
digital payments in 55% and notifications in 52%【282798810985535†L6037-L6042】.
Australia, Austria, Belgium, Denmark, Finland, Hungary, Korea and
Latvia have implemented **all six components**; Australia, Canada,
Estonia, Korea, Mexico, New Zealand and the United Kingdom have adopted
all four enablers【282798810985535†L6042-L6049】.
Digital identity adoption varies widely: Nordic countries, Korea and
the Netherlands have >90% population coverage thanks to strong public–private
collaboration【282798810985535†L6059-L6064】, whereas in about one‑fifth of
surveyed countries less than a quarter of citizens use digital identity
solutions【282798810985535†L6065-L6067】.  This underscores the importance
of inclusive design, outreach and collaboration.

## Lessons for GRGF

* **Inclusive and accountable design** – DPI must be inclusive and
  publicly accountable【613189595351783†L52-L59】.  GRGF should continue to
  emphasise rights‑respecting design, incorporating privacy and
  accountability mechanisms.
* **Interoperability and openness** – Governments that adopt interoperability
  frameworks and open standards are better positioned to scale DPI【282798810985535†L6028-L6048】.
  GRGF’s architecture already champions open standards and modular
  components; this research reinforces the need to align with
  international interoperability and API standards.
* **Public–private partnerships** – High adoption of digital identities
  correlates with strong collaboration with private sector actors such
  as banks【282798810985535†L6059-L6064】.  GRGF’s commercial arms (integration,
  certification, premium modules) should cultivate partnerships with
  financial institutions, telecoms and technology providers while
  preserving custodial neutrality.
* **Cross‑country cooperation** – Collective action through initiatives
  like 50‑in‑5 shortens DPI learning curves and reduces duplication【613189595351783†L61-L73】.
  GRGF can engage with such campaigns to share lessons and adopt
  specifications as digital public goods.
* **Avoiding monopolies and lock‑in** – The risk of digital monopolies
  underscores the importance of vendor‑neutral infrastructure and
  transparency【613189595351783†L69-L73】.  GRGF’s open, modular design and
  dual‑licensing model help mitigate lock‑in and foster sustainable
  ecosystems.

These insights should inform ongoing advocacy, stakeholder engagement and
international collaboration as GRGF moves from pilot to global scale.