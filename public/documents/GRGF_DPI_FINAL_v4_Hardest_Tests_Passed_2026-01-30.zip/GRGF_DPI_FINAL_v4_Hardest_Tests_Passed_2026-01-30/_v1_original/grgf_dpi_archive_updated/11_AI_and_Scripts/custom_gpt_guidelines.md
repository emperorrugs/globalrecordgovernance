# Guidelines for Building Custom GPT Assistants for GRGF

This document explains how to create custom GPT assistants using OpenAI’s GPT Builder
feature (available to ChatGPT Plus, Pro, Team, Enterprise and Edu subscribers)
and how these assistants can support the **Global Records & Governance
Framework (GRGF)** project.  It also includes advice on protecting privacy and
adhering to the rights‑respecting principles that underpin GRGF.

## Overview of GPT Builder

OpenAI allows users on eligible plans to create **custom GPTs**—tailored
versions of ChatGPT that combine your own instructions, knowledge files and
capabilities【673729415077656†L16-L40】.  You can start by visiting the GPTs
editor at `https://chatgpt.com/gpts/editor` or by selecting **Create** in
`https://chatgpt.com/gpts`【673729415077656†L27-L33】.  The editor has two tabs:

* **Create** – Where you converse with the GPT Builder to describe the
  assistant you want.  For example, you can say “Make a neutral legal expert
  who explains GRGF’s compliance requirements” or “Create a training tutor
  that helps civil servants learn how to use GRGF tools”【673729415077656†L32-L35】.
* **Configure** – Where you set the name, description and capabilities of your
  GPT.  You can upload up to 20 files (e.g., GRGF documents or training
  manuals) as knowledge for the GPT to reference【673729415077656†L59-L65】, add
  detailed behavioural instructions, define conversation starters, choose
  whether the GPT may browse the web or generate images or code, and enable
  **Custom Actions** or **Apps** integration【673729415077656†L64-L79】.

When ready, click **Publish** to share your GPT privately or publicly【673729415077656†L42-L43】.
You can manage sharing permissions, version history and access within
workspace settings【673729415077656†L81-L116】.  Uploaded knowledge may appear
in the GPT’s outputs, so avoid providing confidential or personal data.

## Designing GRGF‑Specific GPTs

To support the GRGF project, consider building different GPTs for different
stakeholders and tasks:

1. **Policy & Legal Advisor** – Provides explanations of GRGF’s legal basis,
   digital admissibility, privacy safeguards and cross‑jurisdiction recognition.
   Upload model legislation, policy briefs and the Authoritative Master Record
   so the assistant can cite relevant clauses.  Configure it to avoid
   providing legal advice beyond the uploaded texts and to remind users that
   consultation with qualified counsel is essential.

2. **Training Tutor** – Acts as an instructor for civil servants, auditors,
   technologists and community advocates.  Upload training curricula and
   manuals.  Use the **Prompt Starters** feature to suggest scenarios
   (“How do I set up RIRS?” or “Explain the custodial independence principle”).
   Enable **Code Interpreter & Data Analysis** if you want the tutor to walk
   through sample dashboards or perform simple analyses.【673729415077656†L64-L65】

3. **Implementation & Troubleshooting Assistant** – Helps technical teams with
   installation and integration.  Upload technical specifications (RIRS,
   RECO, EAE) and the integration guide.  Provide instructions that it
   should ask for context before answering and refer to the appropriate
   document sections.

4. **Investor & Funding Concierge** – Summarises the business plan, IP
   valuation report and investor deck.  Provide conversation starters like
   “What is the projected ROI of GRGF?” and “Explain the revenue model”.

5. **Community Engagement Facilitator** – Answers questions from the public.
   Upload the executive summary, policies & procedures, and FAQs.  Set
   instructions to respond in plain language, avoid jargon and emphasise
   inclusivity and rights‑respecting principles.

For each GPT, clearly delineate its scope and instruct it to cite sources
within your knowledge files whenever possible.  Keep the behavioural
instructions concise but explicit—state what the assistant should and
shouldn’t do.  For example, “If you do not know the answer, say you do
not know and suggest consulting the GRGF helpdesk.”

## Privacy, Ethics and Safety Considerations

When building custom GPTs, adhere to GRGF’s rights‑respecting principles:

* **Purpose limitation** – Upload only the information required for the GPT’s
  purpose.  Do not include personal data or sensitive records【508747426460165†L1666-L1671】.
* **Transparency and accountability** – Document the sources provided to the GPT
  and communicate to users how the assistant is trained and limited.  Use
  persistent identifiers from the metadata manifest to reference files.
* **Inclusivity and accessibility** – Write instructions that encourage
  accessible language, multilingual support and the use of clear, inclusive
  examples.  Reference inclusive design guidelines from your training
  curricula to ensure the assistant accounts for diverse users【79616683468802†L420-L552】.
* **Human oversight** – Remind users that the assistant is an automated
  tool and that critical decisions should involve human review, especially
  for legal, policy or procurement matters.
* **Compliance** – Ensure that the GPT does not provide advice that would
  violate data protection laws or professional regulations.  For instance,
  instruct your legal GPT not to draft contracts but to summarise
  provisions from approved templates.

## Maintenance and Updates

Once published, you can monitor usage and update your GPTs as new
documents, laws or standards emerge【673729415077656†L83-L89】.  Be sure to
remove outdated files and re‑upload revised versions to maintain accuracy.
Integrate the GPT with your archive’s metadata manifest so that new files
are automatically flagged for inclusion.  Regularly review user feedback to
improve instructions, conversation starters and capabilities.  When needed,
use the **Version History** feature to roll back to a previous state or
create a new version with improved content.

By following these guidelines, you can create purpose‑built GPT assistants
that enhance access to the GRGF archive and support stakeholders across
legal, technical, training, investment and public engagement domains.