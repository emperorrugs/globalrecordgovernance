"""
search_util.py – Simple metadata search utility for the GRGF DPI digital archive.

This command line tool helps you locate documents within the GRGF digital archive
using keywords.  It reads the metadata_manifest.csv file and performs a
case‑insensitive search on both the file path and description columns.  The
script prints matching PIDs, file paths and descriptions to stdout.  You can
save or modify this script to suit your own workflows (for example, to export
results as JSON or integrate with a GUI).

Usage:

    python3 search_util.py <query>

Example:

    python3 search_util.py "training"

The script assumes it is located under the 11_AI_and_Scripts directory in
the GRGF archive.  By default it looks for the metadata_manifest.csv file in
the `../00_Digital_Preservation` folder relative to its own location.  If you
move the script elsewhere, update the MANIFEST_PATH constant accordingly.

The code uses only Python's built‑in csv module to maximise portability and
avoid external dependencies.  Feel free to extend it with pandas or other
libraries if needed.
"""

import csv
import os
import sys


# Relative path to the metadata manifest within the archive.  Adjust this if the
# directory structure changes.
MANIFEST_PATH = os.path.join(os.path.dirname(__file__), '..', '00_Digital_Preservation', 'metadata_manifest.csv')


def search_manifest(query: str) -> None:
    """Search the metadata manifest for rows containing the given query.

    Args:
        query: A case‑insensitive keyword to search for.
    """
    query = query.lower()
    if not os.path.exists(MANIFEST_PATH):
        print(f"Metadata manifest not found at {MANIFEST_PATH}.")
        return
    with open(MANIFEST_PATH, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        matches = []
        for row in reader:
            if query in row['File Path'].lower() or query in row['Description'].lower():
                matches.append(row)
        if not matches:
            print(f"No matches found for query '{query}'.")
            return
        for row in matches:
            print(f"{row['PID']}: {row['File Path']} – {row['Description']}")


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python3 search_util.py <query>")
        sys.exit(1)
    search_query = ' '.join(sys.argv[1:])
    search_manifest(search_query)