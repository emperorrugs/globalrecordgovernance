# AI‑Assisted Metadata Extraction Guidelines

This document provides guidance for using **artificial intelligence (AI)**, particularly large language models (LLMs), to generate descriptive metadata for digital objects in the GRGF archive.  It draws on contemporary case studies from the archival community and emphasises human oversight to ensure accuracy, ethics and compliance.

## 1 Rationale

The GRGF archive contains thousands of digital objects from diverse sources, many of which lack detailed metadata.  Traditional manual cataloguing is slow and resource‑intensive.  Emerging AI models can analyse text and audiovisual content to propose descriptive metadata, dramatically reducing the backlog and improving discoverability【501974477405546†L590-L613】.  However, AI outputs must be reviewed to ensure correctness, avoid hallucinations and mitigate bias【501974477405546†L640-L649】【213662686049885†L55-L82】.

## 2 Workflow Overview

Follow this workflow to integrate AI assistance into metadata creation:

1. **Normalisation:**  Convert the asset into a preservation‑friendly format (e.g., PDF).  For audiovisual files, create transcripts using a speech‑to‑text tool (e.g., WhisperX)【501974477405546†L625-L630】.
2. **Page or Content Selection:**  If the document exceeds 10–12 pages, extract the first and last 5–6 pages which typically contain key metadata (title, author, abstract)【501974477405546†L579-L587】.  This limits processing costs while capturing essential information.
3. **Prompt Preparation:**  Prepare a detailed prompt for the LLM.  The prompt should include:
   * **Task definition:**  Clearly state that the AI must analyse the uploaded text and extract structured metadata following GRGF conventions【501974477405546†L548-L551】.
   * **Role specification:**  Assign the AI the role of “metadata archivist” to encourage careful extraction【501974477405546†L551-L553】.
   * **Metadata schema:**  List each metadata field (e.g., Title, Author, Date, Subject, Description, Rights, Language, Format) with brief instructions.【501974477405546†L554-L557】
   * **Controlled vocabulary:**  Provide a taxonomy or list of authorised subject terms and instruct the model to select terms from the list【501974477405546†L559-L561】.
   * **Output format:**  Request JSON output with specific keys to streamline integration【501974477405546†L563-L565】.
   * **Examples:**  Include a few labelled examples demonstrating the desired input and output format【501974477405546†L566-L567】.
   * **Validation rules:**  Instruct the AI to leave fields blank or mark them “N/A” if information is not present【501974477405546†L569-L571】.
4. **AI Processing:**  Provide the selected content and prompt to the AI model.  Capture the returned JSON metadata and write it to a CSV file keyed to the object’s persistent identifier【501974477405546†L590-L606】.
5. **Human Review:**  Archivists must review AI‑generated metadata for accuracy, completeness and bias.  Correct or delete fields as needed.  Clearly mark any AI‑generated descriptions (e.g., by appending “(AI generated description)” to the Description field)【501974477405546†L632-L633】.  This maintains transparency about provenance.
6. **Import:**  Once approved, import the metadata into the archive’s catalogue.  Update the `metadata_manifest.csv` to reflect enriched descriptions.

## 3 Ethical and Technical Considerations

* **Human‑in‑the‑Loop:**  AI is an assistant, not a replacement【501974477405546†L640-L649】.  Final responsibility for metadata accuracy rests with archivists.
* **Bias and Hallucinations:**  LLMs may reflect biases in training data and produce plausible‑sounding errors.  Be cautious when describing people, communities or events; cross‑check AI outputs against authoritative sources【213662686049885†L65-L80】.
* **Data Protection:**  Do not feed personally identifiable information (PII) into external AI services without consent and appropriate data processing agreements.  Use anonymised or redacted content where possible.
* **Cost Management:**  Processing long documents with commercial AI APIs can be expensive.  Use page limits and open‑source models when appropriate【501974477405546†L579-L587】.
* **Provenance:**  Clearly distinguish human‑generated and AI‑generated metadata.  Document the version of the AI model and date of generation for future reference.

## 4 Prompt Template

Below is a generic prompt template that can be adapted for different assets.  Replace the placeholder text in square brackets with the appropriate metadata schema and controlled vocabularies.

```
You are a metadata archivist for the GRGF digital archive.  Your task is to analyse the following document and extract structured metadata according to the GRGF metadata schema.  Use the following fields: [Title, Author, Date, Subject, Description, Rights, Language, Format, Keywords].

Use only terms from this controlled vocabulary for the Subject field: [list of authorised subject terms].

Return the metadata as JSON with keys exactly matching the field names.  If a field is not present, leave it blank or write "N/A".  Do not infer information not contained in the document.  Here are examples of the desired output format:

Example 1:
Input: A document titled "Open Standards for Digital Preservation" by Jane Doe (2025) …
Output:
{
  "Title": "Open Standards for Digital Preservation",
  "Author": "Jane Doe",
  "Date": "2025",
  "Subject": "Digital Preservation",
  "Description": "This document explains…",
  "Rights": "CC BY-NC-SA",
  "Language": "English",
  "Format": "PDF",
  "Keywords": "Open standards; preservation"
}

Example 2:
[additional examples]
```

## 5 Compliance with Rights‑Respecting Principles

AI usage must align with the Freedom Online Coalition’s rights‑respecting DPI principles.  This means designing workflows that protect privacy, avoid discrimination, promote inclusivity and ensure transparency【254170641636848†L113-L167】.  Always obtain necessary permissions and respect local laws before processing sensitive content.  Engage stakeholders, including community advocates, in developing the controlled vocabularies and reviewing AI outputs to ensure cultural sensitivity.
