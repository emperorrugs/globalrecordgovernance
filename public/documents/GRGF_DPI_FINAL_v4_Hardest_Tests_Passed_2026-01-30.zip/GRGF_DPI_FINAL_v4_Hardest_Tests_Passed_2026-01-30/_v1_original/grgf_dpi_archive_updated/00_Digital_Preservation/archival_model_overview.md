# Digital Preservation Models and Emerging Best Practices

This overview explains the core concepts of internationally recognised digital preservation models and the most recent enhancements adopted by the **GRGF digital archive**.  It draws on the latest *Open Archival Information System (OAIS) Reference Model* and the United States National Archives’ digital preservation strategy to guide our archival architecture.

## 1 OAIS Reference Model

The **OAIS Reference Model** (ISO 14721) provides a comprehensive framework for managing and preserving digital information over the long term.  It defines functional entities (Ingest, Archival Storage, Data Management, Preservation Planning, Administration and Access) and specifies responsibilities for an archive【330698054702117†L169-L205】.  The latest OAIS release (CCSDS 650.0‑M‑3, December 2024) introduces several important updates:

* **Preservation Objectives:**  A new concept called *Preservation Objectives* provides a measurable basis for assessing whether an archive remains independent and continues to meet its mission【587098106816412†L296-L308】.
* **Preservation Watch:**  The Preservation Planning entity has been expanded to include a *Preservation Watch* function.  This function monitors the technology and standards environment and alerts the archive to emerging risks or opportunities that may require updates to preservation plans【587098106816412†L296-L308】.
* **Updated Information Package Definition:**  The definition of the Information Package has been clarified to ensure consistency across documentation【587098106816412†L296-L308】.
* **Additional Preservation Techniques:**  Beyond migration, the model now explicitly acknowledges other preservation techniques (e.g., emulation, encapsulation)【587098106816412†L305-L308】.
* **New Archive Interactions:**  The model defines new types of interactions between archives, including primary‑supporting archive relationships, to facilitate interoperability【587098106816412†L305-L308】.

These enhancements strengthen the OAIS framework by formalising oversight, broadening preservation strategies and clarifying interactions.  GRGF’s archive adopts OAIS as its conceptual backbone, mapping our folders and workflows to the OAIS functional entities and implementing a *Preservation Watch* programme to monitor external developments.

## 2 NARA Digital Preservation Strategy

The **U.S. National Archives and Records Administration (NARA)** publishes a digital preservation strategy emphasising risk‑based management and adherence to the OAIS model.  Key elements relevant to GRGF include:

* **Trusted Digital Repository:**  NARA uses a trusted digital repository based on OAIS concepts, ensuring long‑term access and alignment with ISO 16363 for auditing and certification【982010388358440†L106-L115】.
* **File Management and Format Transformation:**  To minimise preservation workload, NARA transforms files into selected formats that retain significant properties while keeping originals in low‑access storage【982010388358440†L115-L118】.
* **Authenticity:**  All preservation actions must be documented to maintain record authenticity【982010388358440†L119-L123】.
* **Preservation Metadata and Persistent Identifiers:**  NARA assigns persistent digital identifiers to each record and records contextual, administrative, descriptive and technical metadata【982010388358440†L122-L126】.  This ensures that metadata accompany objects throughout their lifecycle.
* **Risk‑Based Approach & Fixity:**  NARA assesses file formats and media for obsolescence risks and performs regular fixity checks (calculating checksums to detect corruption)【982010388358440†L188-L193】.
* **Staff Training and Community Engagement:**  NARA emphasises ongoing training and collaboration with preservation communities to stay abreast of emerging standards and technologies【982010388358440†L127-L137】.

The GRGF archive integrates these practices by recording preservation metadata (see `metadata_manifest.csv`), assigning persistent identifiers to each file and capturing fixity information (see `fixity_checks.csv`), following a risk‑based approach to format migration and providing staff training guidance.

## 3 AI‑Assisted Metadata and Ethical Considerations

Archival backlogs and the sheer volume of digital objects require innovative metadata workflows.  Recent case studies show that **large language models (LLMs)** can assist with metadata creation when used under human supervision.  At the ICAEW Digital Archive, archivists normalised assets to PDF, extracted the first and last pages of large documents, then supplied the text to an LLM with a highly structured prompt specifying task definitions, roles, required metadata fields, taxonomy and output format【501974477405546†L532-L567】.  The AI‑generated results were exported to CSV, reviewed by archivists, and imported into the repository【501974477405546†L590-L609】.  This workflow reduced manual effort and increased discoverability.【501974477405546†L620-L636】.

While AI can rapidly generate summaries and metadata across thousands of records【501974477405546†L640-L643】, human oversight remains essential.  LLMs may hallucinate plausible but incorrect information and cannot capture context or nuance, so archivists must review, correct and validate all AI outputs【501974477405546†L640-L649】.  Scholars also warn that generative AI carries risks of biased outputs and misinformation, underscoring the need for ethical guidelines and transparency【213662686049885†L55-L82】.

The GRGF archive adopts a cautious, *human‑in‑the‑loop* approach to AI‑assisted metadata.  The separate guidance document (`AI_metadata_guidelines.md`) outlines how AI may be used to generate draft metadata while ensuring accuracy, fairness and accountability.  AI‑generated fields are clearly labelled and subject to archivist review.  Ethical use guidelines emphasise transparency, bias mitigation and rights‑respecting practices.

## 4 Open Standards and Interoperability

In line with the Freedom Online Coalition’s rights‑respecting DPI principles, the archive promotes open standards and interoperability【254170641636848†L224-L236】.  File formats are selected for long‑term accessibility, and metadata follows widely adopted schemas (e.g., Dublin Core) to facilitate sharing across repositories.  The inclusion of persistent identifiers, fixity information and comprehensive metadata ensures that GRGF materials remain usable and verifiable for future generations.

## 5 Next Steps

Implementing this updated archival model requires ongoing monitoring and adaptation.  GRGF will:

1. **Establish a Preservation Watch** to monitor file format obsolescence, emerging technologies and policy changes, and to update the preservation plan accordingly.
2. **Conduct regular fixity and authenticity audits** based on the `fixity_checks.csv` records.
3. **Engage with the digital preservation community** to learn from new research, particularly in AI metadata workflows, and to contribute insights from the GRGF deployment.
4. **Update policies and procedures** as international standards evolve, ensuring that the archive remains aligned with human‑rights, privacy and sustainability principles.

This document serves as a high‑level roadmap for aligning the GRGF digital archive with the most current global best practices.