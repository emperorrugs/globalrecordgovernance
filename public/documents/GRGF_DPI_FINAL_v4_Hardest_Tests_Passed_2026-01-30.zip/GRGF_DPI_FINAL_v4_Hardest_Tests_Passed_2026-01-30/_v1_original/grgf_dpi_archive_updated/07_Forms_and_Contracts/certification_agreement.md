# Certification Agreement Template

## 1 Parties

This **Certification Agreement** (the **“Agreement”**) is entered into by and between **[Applicant Name]**, an entity seeking certification of its GRGF implementation (the **“Applicant”**), and the **Global Standards Certification Council (GSCC)** or its authorised certification body (the **“Certification Body”**).  The Applicant and the Certification Body are collectively referred to as the **“Parties.”**

## 2 Purpose

The purpose of this Agreement is to set out the terms and conditions under which the Certification Body will evaluate the Applicant’s implementation of the Global Records & Governance Framework (GRGF) and issue a certification if the implementation meets the **Institutional Integrity Infrastructure Standard** (IIIS) and other applicable GRGF standards【194634997416537†L61-L107】.

## 3 Certification Scope

1.  **Evaluation:** The Certification Body shall assess the Applicant’s implementation against the GRGF standards, including execution‑time event capture, custodial independence, privacy‑by‑design and interoperability requirements【77671785459166†L36-L107】【508747426460165†L1666-L1671】.
2.  **Audit Process:** Evaluation shall include document reviews, on‑site inspections, interviews and technical testing.  The process follows impartiality and confidentiality rules, ensures representation of stakeholders and is aligned with rights‑respecting DPI principles【254170641636848†L150-L178】.
3.  **Certification Decision:** The Certification Body will issue a certification decision based on findings.  The decision may be certification, conditional certification (with corrective actions) or denial.

## 4 Applicant Obligations

1.  Provide all necessary documentation, access to facilities, and staff cooperation to facilitate the audit.
2.  Ensure that the implementation remains compliant with GRGF standards and applicable laws throughout the certification process.
3.  Notify the Certification Body of any material changes in the system design, operations, or governance that may affect certification.
4.  Pay the certification fees as specified in Annex A to this Agreement.

## 5 Certification Body Obligations

1.  Conduct evaluations impartially, transparently and with due diligence.  The Certification Body shall avoid conflicts of interest and uphold the independence of the certification process【508747426460165†L923-L934】.
2.  Maintain confidentiality regarding Applicant information and records.
3.  Provide detailed audit findings, including non‑conformities and recommendations for corrective actions.
4.  Issue a certification decision within the timeframe specified in Annex B.

## 6 Validity and Surveillance

1.  Certification shall be valid for a period of **[Three Years]**, provided that the Applicant continues to operate in accordance with the standards.
2.  The Certification Body may conduct surveillance audits during the validity period to ensure ongoing compliance.  Failure to address non‑conformities may lead to suspension or withdrawal of certification.

## 7 Fees

Certification fees consist of an application fee, audit fee, and annual surveillance fee as detailed in Annex A.  All fees are payable within 30 days of invoice.

## 8 Use of Certification Mark

1.  Upon certification, the Applicant may display the GSCC certification mark in accordance with the Certification Body’s brand guidelines.  Use of the mark is limited to the certified implementation and may not imply endorsement of other products or services.
2.  Misuse of the certification mark or misleading statements about certification status shall be grounds for suspension or revocation.

## 9 Confidentiality & Data Protection

1.  All data and information obtained during certification, including personal data and system documentation, shall be treated as confidential.  Processing of personal data shall adhere to privacy and security principles, including data minimisation, purpose limitation and transparency【254170641636848†L170-L186】.
2.  The Certification Body shall store audit records securely and retain them only as long as necessary for certification, surveillance and legal obligations.

## 10 Disputes & Appeals

1.  The Applicant has the right to appeal certification decisions in accordance with the GSCC appeals procedure.  Appeals shall be submitted in writing within 30 days of notification.
2.  Disputes arising under this Agreement shall be resolved by negotiation and, failing resolution, may be submitted to arbitration in [jurisdiction].

## 11 Termination

This Agreement terminates when certification is issued or denied and all fees are paid.  Either Party may terminate if the other materially breaches its obligations.

## 12 Governing Law

This Agreement shall be governed by and construed in accordance with the laws of **[Governing Jurisdiction]**.

## 13 Miscellaneous

1.  **Entire Agreement:** This Agreement constitutes the entire agreement between the Parties regarding certification.  Any amendments must be in writing and signed by both Parties.
2.  **Severability:** If any provision is invalid, the remainder shall remain valid.
3.  **Assignment:** The Applicant may not assign this Agreement without the Certification Body’s prior consent.
