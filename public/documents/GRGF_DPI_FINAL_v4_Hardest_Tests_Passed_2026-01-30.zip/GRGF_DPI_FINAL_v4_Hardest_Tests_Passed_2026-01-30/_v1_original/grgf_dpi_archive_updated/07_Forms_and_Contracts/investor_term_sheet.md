# Investor Term Sheet Template

This **Term Sheet** summarises the principal terms for a potential investment in a company (**“Company”**) established to commercialise value‑added services of the **Global Records & Governance Framework (GRGF)**.  This document is non‑binding and for discussion purposes only.

## 1 Securities Offered

**Type of Securities:** Series A Preferred Shares (or other).  
**Amount Raised:** [USD X million].  
**Pre‑Money Valuation:** [USD Y million], based on IP valuation ranges (conservative case: USD 30–50 M; moderate case: USD 200 M; aggressive case: USD 1 B+)【93724969095203†L803-L831】.

## 2 Use of Proceeds

Funds will be used to: (i) develop and market premium GRGF modules and integration services; (ii) scale global deployments; (iii) fund research & development and open‑source contributions; (iv) cover operating expenses and working capital.

## 3 Key Terms

1.  **Dividend:** [e.g., Non‑cumulative annual dividend of 8% of purchase price when and if declared by the Board].
2.  **Liquidation Preference:** 1× non‑participating preference on the original investment amount, senior to common stock.
3.  **Conversion:** Convertible into common stock at any time at the investor’s option.
4.  **Anti‑dilution:** Weighted average protection in the event of subsequent equity issuances at a lower price.
5.  **Voting Rights:** Preferred shares vote together with common stock on an as‑converted basis.  Protective provisions require consent of preferred holders for major actions.
6.  **Board Representation:** Investors elect [1] board member, with the remainder elected by common holders and independent directors.
7.  **Rights of First Refusal & Co‑sale:** Investors shall have rights of first refusal and co‑sale on share transfers by founders.

## 4 Conditions Precedent

1.  Completion of legal, technical and financial due diligence.
2.  Formal creation of the Company, including adoption of articles of incorporation, bylaws and allocation of intellectual property rights.
3.  Execution of definitive agreements, including Shareholders’ Agreement, Investors’ Rights Agreement and Stock Purchase Agreement.

## 5 Closing Date

Target closing within [90] days of signing this Term Sheet, subject to satisfaction of conditions precedent.

## 6 Confidentiality

The terms and existence of this Term Sheet shall be kept confidential by the Parties and shall not be disclosed except to their respective advisors, investors or as required by law.

## 7 No Shop

For a period of [60] days following execution of this Term Sheet, the Company shall not solicit or enter into discussions with any other potential investors regarding a transaction of a similar nature without the consent of the investors.

## 8 Exclusivity

The investors shall have exclusive rights to negotiate definitive agreements for the investment during the No Shop period.

## 9 Governing Law

This Term Sheet is governed by the laws of **[jurisdiction]**.  It is non‑binding and does not constitute a commitment to invest.  Binding obligations arise only upon execution of definitive agreements.

## 10 Investor & Company Acknowledgment

Accepted and agreed by:

| Party | Signature | Name | Date |
|------|-----------|------|------|
| Company | | | |
| Investor | | | |
