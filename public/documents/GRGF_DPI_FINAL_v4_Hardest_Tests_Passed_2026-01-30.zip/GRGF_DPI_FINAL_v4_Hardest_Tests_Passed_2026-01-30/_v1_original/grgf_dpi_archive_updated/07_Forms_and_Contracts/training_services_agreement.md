# Training Services Agreement Template

## 1 Parties

This **Training Services Agreement** (the **“Agreement”**) is made between **[Training Provider]**, an organisation specialising in capacity building for digital public infrastructure, and **[Client]**, a government agency, institution or other organisation seeking training related to the Global Records & Governance Framework (GRGF).

## 2 Services

The Training Provider agrees to deliver the following services (the **“Training Services”**):

1.  **Curriculum Development:** Tailor training curricula for public officials, auditors, technologists and community advocates based on the standardised GRGF training manuals【254170641636848†L124-L139】.
2.  **Course Delivery:** Provide in‑person or online courses, workshops, and seminars covering GRGF concepts, technical implementation, legal considerations, privacy & security, and inclusion.  Courses shall incorporate interactive exercises and case studies【254170641636848†L160-L172】.
3.  **Certification & Assessment:** Administer assessments and certification exams.  Provide continuing education modules for maintaining certifications.
4.  **Training Materials:** Develop and deliver training materials, slides, handouts and recordings.  Materials shall be provided in accessible formats and local languages as required.

## 3 Responsibilities

### 3.1 Training Provider

1.  Deliver high‑quality training in accordance with internationally recognised adult learning principles and rights‑respecting DPI guidelines【254170641636848†L113-L133】.
2.  Provide qualified instructors with experience in GRGF implementation, digital governance, privacy and inclusion.
3.  Collect feedback and adapt training to the Client’s needs.
4.  Ensure that personal data of trainees is processed in compliance with privacy and security standards【254170641636848†L170-L186】.

### 3.2 Client

1.  Provide suitable training facilities or technical infrastructure for online delivery.
2.  Ensure attendance of designated staff and timely communication of participant information.
3.  Make timely payments as per Section 4.

## 4 Fees & Payment

1.  The Client agrees to pay fees according to the pricing schedule attached in Annex A.  Fees may cover curriculum development, instructor time, materials and examination administration.
2.  Payments are due within 30 days of invoice receipt.  Late payments may incur interest.

## 5 Confidentiality & Intellectual Property

1.  Training materials are the intellectual property of the Training Provider.  The Client may use the materials internally but shall not reproduce or distribute them externally without prior consent.
2.  Confidential information exchanged during training shall be protected and shall not be used beyond the training purpose.

## 6 Cancellation & Postponement

1.  The Client may postpone or cancel training by providing at least 14 days’ notice.  Cancellations within 14 days may incur a cancellation fee.
2.  The Training Provider may reschedule training due to circumstances beyond its control and will coordinate with the Client to find suitable dates.

## 7 Limitation of Liability

The Training Provider’s liability for any claim arising out of this Agreement is limited to the amount of fees paid.  Neither Party shall be liable for consequential damages.

## 8 Dispute Resolution

Disputes shall be resolved through negotiation, failing which the Parties may refer the matter to mediation or arbitration.

## 9 Term & Termination

This Agreement enters into effect on **[Effective Date]** and continues until completion of the Training Services or until terminated by either Party with 30 days’ notice.  Termination does not affect payment obligations for services already delivered.

## 10 Governing Law

This Agreement is governed by the laws of **[jurisdiction]**.
