# Data‑Sharing Agreement Template

## 1 Parties

This **Data‑Sharing Agreement** (“**Agreement**”) is made between **[Data Provider]** and **[Data Recipient]** (collectively the **“Parties”**).  
The purpose of this Agreement is to set out the terms under which the Parties will exchange data through the Global Records & Governance Framework (GRGF) while respecting privacy, security, and human rights【254170641636848†L170-L186】.

## 2 Definitions

1.  **Personal Data:** Any information relating to an identified or identifiable natural person.
2.  **Shared Data:** Data provided by the Data Provider to the Data Recipient under this Agreement.
3.  **Processing:** Any operation performed on data, including collection, storage, transmission, or deletion.

## 3 Purpose & Scope

1.  The Parties agree to share data solely for **[specific purpose]**, for example, delivering social benefits, auditing public procurement or enabling cross‑border recognition of academic credentials.  
2.  Data sharing shall be limited to the minimum necessary to fulfil the agreed purpose and shall comply with applicable laws and international human rights standards【254170641636848†L113-L133】.

## 4 Data Governance & Privacy Principles

The Parties shall adhere to the following principles:

1.  **Human Rights & Inclusivity:** Data sharing shall uphold human rights, inclusivity and non‑discrimination【254170641636848†L113-L133】【254170641636848†L124-L139】.
2.  **Transparency & Accountability:** Both Parties shall document data flows, purposes, and lawful bases for processing.  They shall implement oversight mechanisms to ensure accountability【254170641636848†L152-L163】.
3.  **Privacy & Security:** Data shall be protected through encryption, access control, audit logs, and pseudonymisation【254170641636848†L170-L186】【508747426460165†L1666-L1671】.  Each Party shall implement robust security measures and promptly report any data breach.
4.  **Purpose Limitation & Data Minimisation:** Data shall be collected and used only for the stated purpose and shall be limited to what is necessary.  Unused personal data shall be anonymised or deleted.
5.  **Legal Basis & Consent:** Where required, data subjects’ consent shall be obtained, or another lawful basis shall be identified.

## 5 Obligations of the Data Provider

1.  Ensure that data is accurate, up to date and collected lawfully.  
2.  Provide data in an agreed format and maintain documentation describing the data fields, sources and lawful basis for sharing.
3.  Notify the Data Recipient of any restrictions on use or conditions under which data may be shared.

## 6 Obligations of the Data Recipient

1.  Use the shared data only for the agreed purpose and comply with data minimisation and privacy safeguards.
2.  Maintain adequate technical and organisational measures to protect shared data against unauthorised access or processing.
3.  Keep records of processing activities and enable audits by the Data Provider or regulatory authorities.

## 7 Cross‑Border Data Transfers

If data is transferred across borders, the Parties shall ensure that appropriate safeguards are in place, such as data transfer agreements consistent with international standards, privacy legislation and GRGF sovereignty preservation principles【254170641636848†L188-L205】.

## 8 Retention & Disposal

1.  Shared data shall be retained only as long as necessary to fulfil the purpose or as required by law.
2.  Upon expiry or termination of this Agreement, the Data Recipient shall securely delete or return the shared data and certify deletion.

## 9 Liability & Indemnity

Each Party shall be responsible for compliance with its obligations under this Agreement and applicable law.  Parties shall indemnify each other from claims arising from their breach of this Agreement or applicable data protection laws.

## 10 Dispute Resolution

Disputes shall be resolved amicably through negotiation.  Failing resolution, disputes may be submitted to mediation and subsequently to arbitration under mutually agreed rules.

## 11 Governing Law

This Agreement is governed by the laws of **[jurisdiction]**, subject to applicable international human rights standards.

## 12 Term & Termination

This Agreement enters into effect on **[Effective Date]** and continues until the Parties agree that data sharing is no longer required.  Either Party may terminate with 30 days’ notice.  Termination does not relieve the Parties of obligations regarding confidential data and retention.
