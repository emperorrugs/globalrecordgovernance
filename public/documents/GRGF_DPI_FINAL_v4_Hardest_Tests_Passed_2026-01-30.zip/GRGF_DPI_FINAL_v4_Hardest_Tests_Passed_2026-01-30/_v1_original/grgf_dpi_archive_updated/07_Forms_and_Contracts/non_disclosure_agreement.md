# Non‑Disclosure Agreement (NDA) Template

## 1 Parties

This **Non‑Disclosure Agreement** (the **“Agreement”**) is entered into by and between **[Discloser]** and **[Recipient]**.  Each Party discloses to the other certain confidential information relating to the Global Records & Governance Framework (GRGF), including but not limited to technical specifications, business plans, evaluation results, and personal data (the **“Confidential Information”**).

## 2 Purpose

The Parties wish to explore potential collaboration or other business arrangements concerning GRGF.  In connection with such discussions, each Party may disclose Confidential Information.  The Recipient agrees to use the Confidential Information solely for evaluating the potential business relationship.

## 3 Confidential Information

“Confidential Information” means all information disclosed by either Party, whether in written, oral, electronic or other form, that is designated as confidential or which, given its nature, a reasonable person would understand to be confidential.  Confidential Information includes personal data, trade secrets, prototypes, roadmaps, financial information, and any documents created under the GRGF project.  Information is not confidential if it:

1.  is or becomes publicly available through no fault of the Recipient;  
2.  was lawfully known to the Recipient prior to disclosure;  
3.  is received by the Recipient from a third party without breach of any obligation; or  
4.  is independently developed by the Recipient without use of the Discloser’s information.

## 4 Obligations of the Recipient

1.  The Recipient shall use the Confidential Information only for the purpose stated above and shall not disclose it to any third party without the Discloser’s prior written consent.  
2.  The Recipient shall protect the Confidential Information using at least the same degree of care as it uses to protect its own confidential information, and in any event no less than a reasonable standard of care.  
3.  The Recipient shall restrict access to the Confidential Information to employees, consultants or advisors who have a need to know and who are bound by confidentiality obligations at least as protective as those in this Agreement.  
4.  The Recipient shall not make copies of the Confidential Information except as necessary for the evaluation purpose and shall promptly return or destroy all copies upon the Discloser’s request.

## 5 Data Protection

When handling personal data under this Agreement, the Parties shall apply privacy and security principles, including data minimisation, purpose limitation, and transparency【254170641636848†L170-L186】.  Personal data shall be pseudonymised or anonymised where possible and shall not be used to identify individuals【508747426460165†L1666-L1671】.

## 6 Duration

This Agreement comes into effect on **[Effective Date]** and remains in force for **[Three Years]**.  Recipient’s confidentiality obligations survive for five years after termination or expiration of this Agreement.

## 7 No Licence

Nothing in this Agreement grants the Recipient any rights in or to the Discloser’s intellectual property, except the limited right to use the Confidential Information as set forth herein.

## 8 Remedies

The Recipient acknowledges that unauthorised disclosure of Confidential Information may cause irreparable harm to the Discloser.  The Discloser shall be entitled to injunctive relief and any other remedies available at law or equity.

## 9 Miscellaneous

1.  **Governing Law:** This Agreement shall be governed by the laws of **[jurisdiction]**.  
2.  **Entire Agreement:** This Agreement constitutes the entire agreement between the Parties with respect to its subject matter.  
3.  **Severability:** If any provision is found invalid, the remainder shall continue in full force.
