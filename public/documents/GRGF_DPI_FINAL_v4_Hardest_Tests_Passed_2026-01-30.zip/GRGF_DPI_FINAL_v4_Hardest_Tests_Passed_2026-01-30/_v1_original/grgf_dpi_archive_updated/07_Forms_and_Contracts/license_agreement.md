# Dual‑Licence Agreement Template

## 1 Parties

This **Dual‑Licence Agreement** (the **“Agreement”**) is made between **[Licensor]**, representing the GRGF inventor and/or authorised rights holders, and **[Licensee]**, an entity wishing to utilise GRGF code, documentation, and premium modules.

## 2 Background

1.  The **Global Records & Governance Framework (GRGF)** is released under an open‑source licence (e.g., Apache 2.0) for the core components to encourage wide adoption, transparency, and innovation【254170641636848†L238-L246】.  
2.  The Licensor also offers value‑added modules, proprietary enhancements and professional support under commercial terms.  These modules may include advanced analytics, AI‑assisted anomaly detection, custom dashboards, and integration connectors.

## 3 Licence Grants

### 3.1 Open‑Source Licence

The core GRGF software, standards and documentation are licensed to the Licensee under the Apache 2.0 licence (or similar).  The Licensee may use, copy, modify and distribute the core in accordance with the open‑source terms, provided that attribution is given and any modifications are properly documented.

### 3.2 Commercial Licence

1.  **Scope:** Subject to payment of fees, the Licensor grants the Licensee a non‑exclusive, non‑transferable, worldwide licence to use the proprietary GRGF modules specified in the **Order Form**, solely for the Licensee’s internal operations.  
2.  **Restrictions:** The Licensee may not sublicense, reverse engineer or distribute the proprietary modules except as permitted herein.  
3.  **Term:** The commercial licence term is one year, renewable upon mutual agreement and payment of the applicable renewal fees.

## 4 Fees

1.  **Licence Fee:** The Licensee shall pay the licence fee specified in the Order Form.  Fees are based on factors such as user count, transaction volume, or custom features.
2.  **Support & Maintenance:** Support services are provided under a separate maintenance agreement.  Fees for support are set out in the maintenance agreement.

## 5 Intellectual Property Rights

1.  The Licensor retains all intellectual property rights in the proprietary modules.  The Licensee acquires only a limited licence and no ownership rights.  
2.  Any feedback or suggestions provided by the Licensee may be incorporated into the GRGF project; the Licensor may use such feedback without obligation.

## 6 Confidentiality & Data Governance

The Licensee shall protect confidential information, including source code, trade secrets, and any personal data encountered when using the proprietary modules.  Data shall be processed in compliance with privacy and security principles【254170641636848†L170-L186】 and applicable laws.  In particular, the Licensee shall ensure that personal data is only processed for authorised purposes, is minimised, and is anonymised or pseudonymised wherever possible【508747426460165†L1666-L1671】.

## 7 Warranties & Disclaimers

1.  The Licensor warrants that it has the right to grant the licence.  
2.  The proprietary modules are provided “as‑is.”  The Licensor disclaims all implied warranties of merchantability or fitness.  
3.  The Licensor does not warrant that the proprietary modules will meet the Licensee’s requirements or be error‑free.

## 8 Limitation of Liability

Except for liability arising from intellectual property infringement or wilful misconduct, the Licensor’s aggregate liability shall not exceed the fees paid under this Agreement.  The Licensor shall not be liable for indirect or consequential damages.

## 9 Termination

Either Party may terminate this Agreement for material breach by the other Party, with 30 days’ notice and opportunity to cure.  Upon termination, the Licensee shall cease using the proprietary modules and delete all copies.

## 10 General Provisions

1.  **Entire Agreement:** This Agreement, along with any Order Form, constitutes the entire understanding between the Parties.  Amendments must be in writing and signed.  
2.  **Governing Law:** This Agreement shall be governed by the laws of **[jurisdiction]**.
3.  **Notice:** Notices shall be sent by certified mail or email to the addresses specified by the Parties.  
4.  **Severability:** If any provision is held invalid, the rest shall remain in effect.
