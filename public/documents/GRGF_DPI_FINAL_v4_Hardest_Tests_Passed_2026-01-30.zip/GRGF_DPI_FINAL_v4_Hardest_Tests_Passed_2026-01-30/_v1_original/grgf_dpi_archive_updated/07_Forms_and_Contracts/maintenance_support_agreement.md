# Maintenance and Support Agreement Template

## 1 Parties

This **Maintenance and Support Agreement** (the **“Agreement”**) is made between **[Service Provider]**, who has implemented or developed the Global Records & Governance Framework (GRGF) solution, and **[Client]**, the organisation operating the GRGF solution.

## 2 Scope of Services

The Service Provider agrees to provide the following maintenance and support services (the **“Support Services”**) for the GRGF solution:

1.  **Preventive Maintenance:** Regular updates, security patches, and performance optimisations to ensure that GRGF components remain compliant with standards and operate efficiently.  
2.  **Corrective Maintenance:** Investigation and resolution of defects, errors or issues reported by the Client.  
3.  **Technical Support:** 24/7 or agreed‑upon availability of a helpdesk to handle incidents, requests, and service tickets.  Response and resolution times shall be specified in the Service Level Agreement (SLA) annexed hereto.
4.  **Enhancements:** Implementation of minor enhancements and configuration changes that do not require new development.  Major enhancements shall be subject to separate change requests.
5.  **Monitoring & Reporting:** Provision of regular reports on system performance, usage metrics, security alerts and recommendations for improvements【584430089377844†L84-L140】.

## 3 Service Level Agreement (SLA)

1.  **Response Time:** The Service Provider shall acknowledge critical incidents within [1 hour], high‑priority incidents within [4 hours], and normal incidents within [1 business day].
2.  **Resolution Time:** Target resolution times are set out in Annex A and depend on severity levels.  
3.  **Availability:** The Service Provider shall ensure system availability of [99.5%] uptime, excluding scheduled maintenance.
4.  **Escalation:** The Client shall have an escalation path for unresolved issues, including direct access to senior engineers.

## 4 Fees & Payment

1.  The Client shall pay an annual support fee as specified in Annex B.  
2.  Additional fees may apply for major enhancements or changes outside the Support Services.
3.  Payments shall be made within 30 days of invoice date.

## 5 Client Responsibilities

1.  Provide accurate incident reports with sufficient detail to diagnose issues.
2.  Maintain a secure environment, including applying recommended patches, controlling access, and following data governance policies【254170641636848†L170-L186】.
3.  Cooperate with the Service Provider’s staff and provide necessary access to systems and logs.

## 6 Confidentiality & Data Protection

1.  The Service Provider shall maintain confidentiality of the Client’s data and implement privacy and security practices, including encryption, audit trails and pseudonymisation【508747426460165†L1666-L1671】.
2.  Any personal data processed under this Agreement shall be handled in accordance with applicable data protection laws and the principles of the FOC rights‑respecting DPI framework【254170641636848†L170-L186】.

## 7 Warranties & Liability

1.  The Service Provider warrants that Support Services will be performed in a professional and workmanlike manner.
2.  The Service Provider’s liability is limited to the annual support fees paid.  The Service Provider shall not be liable for indirect or consequential damages.

## 8 Term & Termination

1.  This Agreement enters into effect on **[Effective Date]** and continues for **[One Year]**, automatically renewing for successive one‑year terms unless either Party gives 60 days’ notice of non‑renewal.
2.  Either Party may terminate for material breach that is not cured within 30 days.
3.  Upon termination, the Service Provider will provide reasonable assistance to transition support to another provider or to the Client’s internal team.

## 9 Dispute Resolution

Disputes shall be resolved through good‑faith negotiation.  If unresolved, the dispute may be referred to mediation or arbitration under agreed rules.

## 10 Governing Law

This Agreement is governed by the laws of **[jurisdiction]**.
