# Annex G – Submission Checklist & Donor Review Sheet

This checklist ensures that all required materials are included and properly prepared before submitting the GRGF Stage 1 dossier to WIPO, the World Bank, ISO and other stakeholders.  Use this sheet internally and share with donors or reviewers who need to confirm completeness.

## Document completeness

1. **Master Executive Index (Doc 1.1) present and accurate.**
2. **All documents listed in the Master Table of Contents (Doc 1.3) included**, with correct version numbers and classification labels.
3. **Cover and back pages** formatted according to guidelines (Doc 1.4).
4. **Official submission letter (Doc 1.5)** signed by the authorized representative.
5. **Standards catalogue and mapping (Docs 2.1–2.4) included**, verifying compliance with ISO/WIPO/OECD standards.【194634997416537†L61-L107】
6. **Technical specifications (Docs 3.1–3.4)** complete and correctly classified (Restricted or Authoritative).
7. **Economic and valuation reports (Docs 4.1–4.4)** present and up to date.
8. **Legal documents and IP annexes (Docs 5.1–5.4)** reviewed by legal counsel for accuracy and completeness.
9. **Administrative forms (Docs 6.1–6.7)** filled out and ready for submission.
10. **Integration materials (Docs 7.1–7.2)** included, with images properly embedded.

## Quality checks

1. **Metadata** completed for each document (Annex J).  Checksums verified.
2. **File naming conventions** consistent (e.g., “GRGF-ExecutiveSummary-v1.0.pdf”).
3. **Version control log** updated for each document.
4. **Classification labels** clearly visible on covers and footers.
5. **Proofreading** completed (grammar, spelling, formatting) for all public‑safe documents.
6. **Accessibility** considered (e.g., tagged PDFs, alternative text for images).
7. **Virus/malware scan** performed on all digital files.

## Donor/Reviewer questions

| Item | Yes/No | Notes |
|---|---|---|
| All required documents included? |  |  |
| Documents appropriately classified? |  |  |
| Financial analysis matches donor expectations? |  |  |
| Governance and risk mitigation explained? |  |  |
| Gender/inclusion considerations addressed? |  |  |
| Privacy and security safeguards adequate? |  |  |
| Clear pathway for pilot and scale‑up? |  |  |
| Alignment with donor priorities? |  |  |

**Classification:** Authoritative – used internally and shared with donors or reviewers to verify completeness of the dossier.
