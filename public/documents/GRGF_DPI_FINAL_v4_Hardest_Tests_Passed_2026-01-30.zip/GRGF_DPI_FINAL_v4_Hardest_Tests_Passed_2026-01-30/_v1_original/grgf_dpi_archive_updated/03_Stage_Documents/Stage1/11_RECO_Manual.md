# Records Custody Office (RECO) – Operational Manual (Doc 3.2)

## Purpose

The **Records Custody Office (RECO)** oversees the storage, protection and access of GRGF records within a jurisdiction.  This manual provides operational procedures for maintaining chain‑of‑custody and ensuring compliance with legal and privacy requirements.

## Responsibilities

1. **Custody management:** RECOs hold and manage all GRGF logs generated within their jurisdiction.  They ensure that records are stored in secure, tamper‑evident repositories with redundancy and disaster‑recovery measures.
2. **Access control:** RECOs enforce role‑based access policies, allowing only authorized auditors, regulators or courts to view records.  All access is logged and periodically reviewed【508747426460165†L1656-L1671】.
3. **Metadata and classification:** Each record is tagged with its classification level (public, restricted, confidential), retention schedule and applicable legal references.  RECOs maintain a metadata register aligned with ISO 23081【194634997416537†L292-L299】.
4. **Retention and disposition:** RECOs follow statutory retention periods and manage lawful disposition (deletion or archival) of records.  Disposition requires dual authorization and audit logging.
5. **Audit support:** RECOs facilitate audits and investigations by providing relevant records and verifying chain‑of‑custody documentation.

## Procedures

### Record ingestion

1. Receive encrypted event batches from RIRS via secure channels.
2. Verify digital signatures and timestamps; reject any batches that fail validation.
3. Store events in immutable, append‑only storage; update metadata index.

### Access requests

1. Receive formal request specifying the justification (audit, investigation, legal proceeding) and scope (event range, actors, date range).
2. Verify requestor’s authorization level and ensure required approvals.
3. Retrieve records matching the request criteria; provide them through a secure interface.
4. Log the request and fulfillment details for audit purposes.

### Transfer of custody

1. When records must be transferred (e.g., to a higher court), create a transfer package with metadata and cryptographic checksums.
2. Both sending and receiving RECOs sign off on the transfer; update the chain‑of‑custody register.

### Incident response

1. If a breach or compromise is detected, isolate the affected system and notify the oversight board and GSCC.
2. Conduct forensic analysis to determine the scope of the incident and recover data from redundant backups if necessary.
3. Document the incident, mitigation measures and corrective actions.

## Compliance

RECO operations align with ISO 15489 (records management) and ISO 27001/27701 (information security and privacy).  Compliance is assessed through periodic audits and GSCC certification reviews【194634997416537†L144-L151】.

**Classification:** Restricted – internal operational manual for records management officers and custody staff.
