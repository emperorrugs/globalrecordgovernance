# Annex O – WIPO/IPAS Digital Registration Instructions

## Purpose

This annex provides a step‑by‑step guide for submitting GRGF documents and evidence to the World Intellectual Property Organization (WIPO) using its **Industrial Property Administration System (IPAS)**.  Following these instructions ensures that submissions are complete and compliant.

## Preparation

1. **Gather documents:** Collect all Stage 1 documents in their final versions, ensuring they match the Master Table of Contents【194634997416537†L35-L40】.  
2. **Generate metadata:** Complete the Digital Submission Metadata Sheet (Annex J) with standardized metadata (title, author, date, classification, checksums)【194634997416537†L292-L299】.
3. **Check formatting:** Ensure files comply with WIPO’s requirements (PDF/A format, maximum file size limits).  Scan for viruses and malware.

## Submission steps

1. **Log into IPAS:** Using credentials provided by WIPO, log into the IPAS portal.
2. **Create a new submission:** Select *New Filing* and choose the category *Non‑Patented Digital Evidence*.  Enter a short title (e.g., “GRGF Stage 1 Dossier”).
3. **Upload documents:** Upload each document separately.  For each file:
   - Enter the corresponding metadata from Annex J.  
   - Specify the classification (public, restricted).  
   - Provide a brief description (e.g., “Executive Summary”, “Standards Catalogue”).
4. **Upload evidence hashes:** For documents requiring evidence of authenticity (e.g., RIRS logs), upload the corresponding hash files and time‑stamp certificates from the EAE.
5. **Review and confirm:** Use IPAS’s review tool to verify that all documents are uploaded and metadata is correct.  Correct any errors before submission.
6. **Submit for registration:** Click *Submit*.  IPAS will generate a submission reference number and confirmation receipt.
7. **Download confirmation:** Save the registry confirmation (Annex M) and attach it to the submission tracking form (Annex K) for internal records【194634997416537†L320-L327】.

## Post‑submission

1. **Monitor status:** Log into IPAS periodically to check the status of the submission.  Respond promptly to any requests for clarification from WIPO officials.
2. **Update records:** Update the submission tracking form (Annex K) with the date of submission, reference number and any additional notes.
3. **Maintain copies:** Store a copy of all submitted materials, confirmation receipts and correspondence in the GRGF records repository managed by the RECO.

**Classification:** Authoritative – procedural guidance to accompany the official submission; not sensitive itself but should be handled by authorized staff.
