# Annex B – Standards Architecture & Mapping Table

## Purpose

Annex B provides a **technical mapping** between the Global Records Governance Standards (GRGS) and existing international standards to ensure interoperability and compliance.  The table below summarizes how GRGF aligns with ISO, WIPO and OECD frameworks.

| GRGS Standard | Mapped Standard | Alignment & rationale |
|---|---|---|
| **GRGS 1000 (Terminology & Definitions)** | **ISO 15489 – Records Management** | Provides consistent vocabulary for records management, ensuring GRGF terms align with ISO definitions of records, metadata and retention【77671785459166†L36-L107】. |
| **GRGS 1100 (Data & Metadata Schema)** | **ISO 23081 – Metadata for Records**; **WIPO ST.96 – Metadata Schema** | Aligns GRGF metadata fields (event ID, actor, timestamp, jurisdiction, classification) with ISO 23081 and WIPO ST.96 to support legal interoperability and digital submission to WIPO【194634997416537†L292-L299】. |
| **GRGS 1200 (Hashing & Time‑Stamping)** | **ISO 14641 – Electronic Archiving**; **RFC 3161 – Time-Stamp Protocol** | Uses standardized hash algorithms (e.g., SHA‑256) and trusted timestamp authorities to ensure non‑repudiation and legal admissibility【77671785459166†L120-L142】. |
| **GRGS 2000 (Observer Service Interface)** | **ISO/IEC 19770 – Software Asset Management** | Utilizes standard API definitions and logging best practices to capture events without disrupting operations【508747426460165†L144-L153】. |
| **GRGS 2100 (Event Ingestion & Messaging)** | **ISO/IEC 19510 (BPMN)**; **ISO/IEC 23127 (Event Streaming)** | Specifies asynchronous message bus protocols and event schemas aligned with international event‑streaming standards【508747426460165†L1705-L1717】. |
| **GRGS 2200 (Distributed Storage & Custody)** | **ISO 15489**; **OECD Digital Government Policy Framework** | Incorporates records custody principles (chain‑of‑custody, jurisdictional sovereignty) and OECD guidelines for data stewardship and trust【508747426460165†L1648-L1657】. |
| **GRGS 2300 (Access Control & Privacy)** | **ISO/IEC 27001/27701 (Information Security & Privacy)**; **GDPR** | Implements role‑based access control, pseudonymization and audit logging to protect personal data, meeting privacy‑by‑design requirements【508747426460165†L1666-L1671】. |
| **GRGS 3000 (Institutional Integrity Infrastructure Standard)** | **ISO 30301 (Management Systems for Records)**; **OECD Principles on Good Governance** | Establishes governance roles, oversight boards and certification processes in line with records‑management systems and public governance principles【77671785459166†L120-L142】. |
| **GRGS 3100 (Records Custody Office)** | **ISO 15489**; **ISO 21127 – CIDOC CRM** | Defines custody procedures and metadata models to maintain the authenticity and reliability of records over time. |
| **GRGS 3200 (Evidentiary Assurance Engine)** | **ISO/IEC 17025 – Testing & Calibration Labs** | Adapts testing and verification methodologies for auditing digital evidence to ensure chain‑of‑custody and evidence integrity【194634997416537†L135-L142】. |
| **GRGS 3300 (GSCC Governance)** | **ISO 37000 – Governance of Organizations**; **ISO 38505 – Governance of Data** | Aligns the GSCC’s governance charter with international guidelines on organizational and data governance. |

This mapping demonstrates that GRGF is not a stand‑alone framework but is designed to complement and integrate with existing standards and best practices.  Adhering to this mapping ensures that GRGF records are legally admissible and interoperable across jurisdictions.
