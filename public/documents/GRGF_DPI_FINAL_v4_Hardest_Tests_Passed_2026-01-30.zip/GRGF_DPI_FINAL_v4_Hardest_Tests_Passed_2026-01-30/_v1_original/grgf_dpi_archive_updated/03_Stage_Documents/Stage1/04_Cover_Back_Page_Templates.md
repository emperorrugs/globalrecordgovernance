# Cover & Back Page Templates

## Purpose

Formal submissions to international bodies require consistent and professional presentation.  This document provides guidance for creating cover and back pages for GRGF documents.  It ensures proper branding, classification labelling and version control.

## Cover page elements

1. **Title and subtitle:** Include the full document title (e.g., *Global Records & Governance Framework – Institutional Dossier*) and a concise subtitle describing its purpose.
2. **Logo and identifiers:** Display the GRGF emblem or government crest in the top left corner.  Include the project acronym (GRGF) and document number (e.g., “Doc 1.1”) for reference.
3. **Version and date:** Indicate the version number (e.g., “v1.0”) and date of issuance (e.g., “January 2026”).  This supports auditability and change control.
4. **Classification label:** Mark the document’s classification (Authoritative, Public‑Safe or Restricted) prominently to guide distribution.
5. **Contact information:** Provide the responsible secretariat’s address, email and phone number for queries.
6. **Approval signatures (if required):** For official submission letters, include signature blocks for the authorizing officer and receiving authority.

## Back page elements

1. **Document history:** Provide a table summarizing version changes (e.g., “v0.9 – draft; v1.0 – final”).
2. **Distribution statement:** Reiterate the classification and distribution restrictions (e.g., “This document is public-safe and may be shared widely”).
3. **Legal notices:** Include copyright and intellectual property notices referring to the IP attribution statement and any applicable licences.
4. **List of related documents:** Provide cross‑references to related GRGF documents for ease of navigation (e.g., “See Doc 2.1 – GRGS Standards Catalogue for further details”).

## Formatting guidelines

- Use a clean, professional font (e.g., Arial or Calibri) and standard margins.
- Align text consistently; avoid clutter and ensure readability.
- Use the colour palette consistent with governmental or institutional branding.
- For translations, maintain the same layout while adjusting text to fit the target language.

Following these templates ensures that GRGF documents meet the expectations of international reviewers and adhere to professional presentation standards.
