# Annex N – IP & Attribution Statement

## Purpose

This annex formally records the intellectual property ownership and inventor attribution for the Global Records & Governance Framework (GRGF).  It ensures that rights are clear for legal filings, licensing and commercialisation.

## Statement

1. **Inventor:** The GRGF was conceived, designed and authored by **Tarek Wahid**, who is hereby recognized as the sole inventor【279869053053924†L3-L64】.  His innovations include the execution‑time recording architecture, non‑intrusive observer agents, custodial independence and the GRGS standards catalogues【279869053053924†L114-L137】.
2. **Ownership:** All intellectual property rights in the GRGF, including its software, standards, documentation, and related materials, belong to the inventor.  The inventor retains the right to assign or license these rights to institutions or organizations.
3. **Licensing:** The inventor intends to adopt a **dual‑licensing model**—releasing core standards under an open, royalty‑free licence for public benefit while offering commercial licences for value‑added services.  This aligns with World Bank recommendations to use open standards at the core of digital public infrastructure【180370114329758†L39-L84】.
4. **Attribution requirements:** Any use or implementation of GRGF must acknowledge the inventor and reference this IP attribution statement.  Adaptations or derivative works must clearly identify modifications and respect the original standards’ integrity.
5. **Dispute resolution:** Disputes concerning IP ownership or attribution shall be subject to the laws of the inventor’s jurisdiction and, if necessary, arbitration under the rules of the World Intellectual Property Organization (WIPO).

## Signature

[Signature]

**Tarek Wahid**  
Inventor, Global Records & Governance Framework (GRGF)

**Date:** *[insert date]*

**Classification:** Restricted – confidential legal document for internal use and official filings.
