# Annex J – Digital Submission Metadata Sheet (Template)

## Purpose

This template captures standardized metadata for each GRGF document in the digital submission.  Using a consistent schema ensures interoperability with WIPO ST.96 and ISO 23081【194634997416537†L292-L299】.

| Field | Description | Example |
|---|---|---|
| **Document number** | Unique identifier (e.g., 1.1, 2.1). | 3.2 |
| **Title** | Full title of the document. | Records Custody Office Manual |
| **Version** | Document version (e.g., v1.0). | v1.0 |
| **Author(s)** | Name(s) of primary authors or contributors. | Tarek Wahid |
| **Date issued** | Date of finalization (YYYY‑MM‑DD). | 2026‑01‑27 |
| **Classification** | Authoritative, Public‑Safe or Restricted. | Restricted |
| **Language** | Language of the document (e.g., EN, FR). | EN |
| **Summary** | Brief abstract explaining purpose and contents. | Operational manual for custody protocols. |
| **Keywords** | Keywords describing the subject matter. | records management; chain of custody |
| **Checksum (SHA‑256)** | Cryptographic hash of the file for integrity verification. | [computed hash] |

Populate a metadata sheet for each document before submission.  Include the sheet in the digital bundle and upload it to WIPO’s IPAS system alongside the documents.

**Classification:** Authoritative – required as part of official submission; not distributed beyond registry needs.
