# Annex I – Table of Figures and Tables Index

## Purpose

This annex provides a consolidated index of all figures, tables and diagrams across the GRGF Stage 1 dossier.  It assists readers in quickly locating visual references in both digital and printed materials.

## Figures

| Figure # | Title | Source Document | Page/Section |
|---|---|---|---|
| **Fig 1** | GRGS Standards Tree (hierarchical diagram) | Doc 2.2 – GRGS Standards Tree Infographic | [page reference] |
| **Fig 2** | Integration Flowchart (GRGF record flow) | Doc 7.2 – Integration Flowchart | [page reference] |
| **Fig 3** | Cross‑Sector Impact Graph (ROI across sectors) | Doc 4.1 – Cross‑Sector Impact Report | [page reference] |

## Tables

| Table # | Title | Source Document | Page/Section |
|---|---|---|---|
| **Table 1** | Master Table of Contents (list of deliverables) | Doc 1.3 – Master Table of Contents | entire document |
| **Table 2** | GRGS Standards Catalogue | Doc 2.1 – Standards Catalogue | entire document |
| **Table 3** | Standards Mapping Table | Doc 2.3 – Annex B | entire document |
| **Table 4** | Risk & Mitigation Register | Doc 3.4 – Governance Charter or Risk Register | [section reference] |
| **Table 5** | ROI Scenarios | Doc 4.2 – Cost–Benefit & ROI Analysis | [section reference] |

When compiling final PDFs, insert accurate page numbers or section references in place of [page reference].

**Classification:** Authoritative – reference document for internal and external reviewers.
