# GRGS Standards Tree – Infographic Reference

The diagram below illustrates the hierarchical structure of the **Global Records Governance Standards (GRGS)**.  The foundation is the **1000 series**, which defines core terminology and metadata.  Built on that are the **2000 series** operational protocols for event capture, transmission and storage.  At the top is the **3000 series**, which establishes institutional integrity infrastructure (governance, custody and certification).  This hourglass‑like hierarchy mirrors the World Bank’s “thin waist” model for digital public infrastructure【180370114329758†L39-L84】.

![GRGS Standards Tree](ca3e8857-cbbb-45c9-8311-3865853274b4.png)

**Figure 1:** Hierarchical diagram of GRGF standards.  Each layer builds on the one below it, ensuring interoperability and scalability while preserving a minimal set of core standards.

This infographic is *public‑safe* and may be used in presentations or reports to explain the standards hierarchy to technical and non‑technical audiences.
