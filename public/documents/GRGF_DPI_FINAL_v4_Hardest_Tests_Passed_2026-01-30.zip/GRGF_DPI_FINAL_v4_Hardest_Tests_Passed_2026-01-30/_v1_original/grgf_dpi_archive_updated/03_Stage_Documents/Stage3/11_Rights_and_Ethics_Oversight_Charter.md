# Stage 3 Rights & Ethics Oversight Charter

## Purpose

The mission of the GRGF is to **capture reality with integrity** while protecting individual rights and ensuring that records are used ethically.  This charter establishes a framework for overseeing privacy, ethics and human rights during full deployment and beyond.

## Principles

1. **Respect for privacy:** Only collect what is necessary; apply purpose limitation; secure consent where appropriate; and implement data minimisation【508747426460165†L946-L959】.
2. **Transparency and accountability:** Provide clear information about how records are collected, stored and used; ensure auditability and independent oversight【508747426460165†L923-L934】.
3. **Non‑discrimination:** Ensure that systems do not exacerbate existing inequities; design with accessibility and inclusivity in mind【169712679735660†L79-L88】.
4. **Proportionality:** Ensure that the benefits of record‑keeping outweigh any potential risks; avoid over‑collection or misuse.
5. **Independent oversight:** Establish an independent body to monitor compliance with this charter and investigate complaints.

## Oversight structure

* **Ethics and Rights Board:** Comprised of representatives from human rights organisations, data protection authorities, civil society, academia and user communities.  The board operates independently of the implementing institutions and commercial entities.
* **Mandate:** Review policies, investigate complaints, issue recommendations and publish annual reports on GRGF’s ethical performance.
* **Powers:** Access records (subject to confidentiality constraints), compel cooperation, and recommend remedial actions.  The board has no operational control but can refer serious breaches to regulators.

## Processes

1. **Privacy impact assessments (PIAs):** Mandatory PIAs for new deployments or major changes.  These assessments evaluate risks, benefits and mitigation strategies.
2. **Ethics reviews:** Review proposed uses of records for analytics, research or other secondary purposes to ensure alignment with rights principles.
3. **User consent management:** Implement mechanisms for capturing and managing consent where required, including withdrawal and access requests.
4. **Complaint resolution:** Provide accessible channels for individuals to file complaints about misuse or privacy violations.  Investigate promptly and provide remedies.
5. **Public reporting:** Publish anonymised reports on complaints, findings and recommendations.

## Integration with certification

Ethical compliance is integrated into the GSCC certification program (Document 03).  Institutions must demonstrate adherence to the charter to achieve and maintain certification.

## Continuous improvement

* **Training:** Provide ethics and privacy training to all staff, auditors and contractors.
* **Stakeholder engagement:** Consult with user communities and civil society to refine rights protections and respond to emerging concerns.
* **Review:** Update the charter periodically based on technological developments, legal changes and evaluation findings.

## Conclusion

This charter safeguards rights and ethics throughout the GRGF lifecycle.  By establishing clear principles, structures and processes, the GRGF can deliver its benefits while respecting human dignity and fostering public trust.
