# WIPO Account Creation & IPAS Access Guide

To register GRGF intellectual property (IP) assets and access WIPO’s electronic services (e.g., ePCT, IPAS), an individual must obtain a WIPO account and appropriate access credentials.  This guide summarizes the steps based on WIPO’s published instructions【944033027638681†L9-L33】.

## Create a WIPO Account

1. **Visit the WIPO Account Portal:** Go to the WIPO login/registration page at `https://ipportal.wipo.int` or a localised WIPO service page.
2. **Click “Create a WIPO Account”:** Follow the link labelled “Create a WIPO Account.”  Accounts are individual, not organisational, and require a unique email address【944033027638681†L9-L16】.
3. **Enter Personal Information:** Provide your name, email, and contact details.  Use your official institutional email when representing a government agency or IP office【944033027638681†L48-L53】.
4. **Set a Password:** Create a strong password according to WIPO’s complexity requirements.
5. **Confirm Registration:** You will receive a confirmation email.  Click the link to activate your account.

## Enable Strong Authentication

To access confidential data and file applications (e.g., PCT filings), WIPO requires strong authentication【944033027638681†L20-L25】.

1. **Log In:** After activating your account, log in to the WIPO portal.
2. **Set Up Two‑Factor Authentication (2FA):** WIPO may prompt you to enrol in a second authentication method (e.g., time‑based one‑time password (TOTP) app, SMS, or hardware token).  Follow the instructions to complete setup.
3. **Test Authentication:** Ensure you can log in using both your password and the second factor.

## Request IPAS/IRP Access

The **Industrial Property Administration System (IPAS)** is provided by WIPO to national IP offices (IPOs) under cooperation frameworks【302599941924676†L78-L83】.  Individual inventors or project teams typically do not use IPAS directly; instead they interact through their national IP office or through WIPO’s ePCT system for PCT filings.

1. **Contact Your National IP Office:** To obtain access to IPAS or to lodge records via IPAS, the inventor or custodial agency should coordinate with their national intellectual property office.  The office may create user accounts within IPAS for authorized staff.
2. **Cooperation Agreement:** Countries interested in deploying IPAS must sign a cooperation agreement with WIPO that defines roles, responsibilities, and support【302599941924676†L80-L83】.
3. **Role Assignment:** Within IPAS or ePCT, the IP office’s contact person will liaise with WIPO to assign roles (e.g., Receiving Office (RO), International Searching Authority (ISA), etc.) to individual accounts【944033027638681†L68-L73】.
4. **Training & Support:** WIPO offers training and support for using IPAS.  Ensure authorized staff attend relevant workshops or e‑learning courses.

## Tips for Successful Registration

- **Use Official Email:** Always register with an email domain linked to your institution to facilitate verification.
- **Prepare Documentation:** Have necessary identification and authorization documents ready; some services may require proof of authority from your organisation.
- **Follow National Procedures:** Some countries may require additional steps, such as registering with a government‑wide Single Sign‑On system or obtaining approval from a supervising ministry.
- **Keep Credentials Secure:** Do not share your WIPO account credentials.  Use strong, unique passwords and update them regularly.

By following these steps, project leaders can access WIPO’s systems to register IP assets, file applications and manage communications.  For further assistance, consult your national IP office or WIPO’s support resources.
