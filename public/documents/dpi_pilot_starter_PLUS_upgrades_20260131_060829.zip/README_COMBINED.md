
# DPI Pilot Starter + Upgrades (CICE + VC + Omission)

Folders:
- services/ ... (collector, pseudonymization, proof_builder)
- policies/, db/, web/, infra/, scripts/  (from starter)
- upgrades/ (cice, vc, omission_detector, lib/common.py)

Quick start (local):
1) Follow README.md in the starter to launch services locally.
2) Set the Collector URL for upgrades:
   - mac/linux: export COLLECTOR_URL=http://localhost:8000/ingest
   - windows:   setx COLLECTOR_URL http://localhost:8000/ingest (then new terminal)
3) Run:
   - python upgrades/cice/agent.py
   - python upgrades/vc/issuer.py --event-hash <hash> --subject did:example:me --claim exists=true --out vc.json
   - python upgrades/vc/verifier.py --vc vc.json
   - python upgrades/omission_detector/service.py --rules upgrades/omission_detector/rules.json --store services/collector/_store

Cloud deploy: use the Deploy Kit zip provided earlier, then point COLLECTOR_URL to the cloud Collector URL.
