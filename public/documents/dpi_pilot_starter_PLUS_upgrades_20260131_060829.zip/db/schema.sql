create extension if not exists pgcrypto;

create table if not exists event (
  id            uuid primary key default gen_random_uuid(),
  source_id     text not null,
  schema_version text not null default 'v1',
  occurred_at   timestamptz not null,
  received_at   timestamptz not null default now(),
  subject_ref   text,
  payload_json  jsonb not null,
  hash          bytea not null,
  prev_hash     bytea,
  merkle_leaf   bytea,
  signatures    bytea[]
);
create index if not exists event_occurred_idx on event (occurred_at);
create index if not exists event_payload_idx on event using gin (payload_json);

create table if not exists proof_batch (
  id uuid primary key default gen_random_uuid(),
  merkle_root bytea not null,
  period_start timestamptz,
  period_end   timestamptz,
  batch_size   int not null,
  published_uri text
);

create table if not exists access_log (
  id uuid primary key default gen_random_uuid(),
  actor_id text not null,
  action text not null,
  object_ref text,
  ts timestamptz not null default now(),
  ip inet, device text, result text
);
