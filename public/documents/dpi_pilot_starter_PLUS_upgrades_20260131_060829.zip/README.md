# DPI Pilot Starter (Canada Federal – Best-Practice)

This is a minimal, **pilot-ready scaffold** matching the spec we discussed: append-only event ingestion, pseudonymization, Merkle proof builder, OPA policies, Terraform skeleton, CI, and simple web portals (admin + public proof verify).

> **Note:** This is a starter kit, not a full production build. It’s structured so a team can iterate quickly during the one-week pilot.

## Quick start

```bash
# 1) Services (local dev)
cd services/collector && pip install -r requirements.txt && uvicorn app:app --reload
cd services/pseudonymization && pip install -r requirements.txt && uvicorn app:app --reload
cd services/proof_builder && pip install -r requirements.txt && python job.py

# 2) Policies (tests)
opa test ../policies -v

# 3) Web portals (static dev)
# (Admin/Public are plain HTML stubs using GCWeb styles; replace with your framework of choice)
python -m http.server -d web/admin 8080
python -m http.server -d web/public 8081

# 4) Terraform (skeleton - edit variables first)
cd infra/terraform && terraform init && terraform validate
```

## Services
- **collector**: FastAPI endpoint validating events against a schema and writing to local disk (swap with S3/Aurora in cloud).
- **pseudonymization**: Deterministic tokenization using HMAC (placeholder secret); swap with KMS in cloud.
- **proof_builder**: Hourly job (cron-ready) that builds Merkle trees for batches and emits inclusion proofs.

## Infra
- **infra/terraform**: AWS Canada (ca-central-1) skeleton: provider, S3 buckets (payload/proofs/logs), Object Lock hints, and IAM placeholders.
- **db/schema.sql**: Postgres tables for `event`, `proof_batch`, `access_log`.

## Policies
- **policies/**: OPA/Rego snippets for ABAC and retention.

## Web
- **web/admin**: GCWeb-style admin stub (bilingual toggle, RBAC placeholder).
- **web/public**: Proof verification page (paste proof JSON).

## CI
- **.github/workflows/ci.yml**: Lint/test/policy gate + image signing (placeholder).

---

**Security**: Do not commit real secrets. In cloud, replace HMAC keys with KMS/CloudHSM and use mTLS, IRSA/task roles, and VPC egress controls.

**License**: MIT
