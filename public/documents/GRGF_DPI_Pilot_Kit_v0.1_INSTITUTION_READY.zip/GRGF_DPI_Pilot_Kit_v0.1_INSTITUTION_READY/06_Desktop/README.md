# Desktop Wrapper (Prototype)

`grgf-dpi-electron.zip` is an early desktop wrapper concept that attempts to open a local web portal and start docker-compose.

It is included for completeness only and is **not required** for pilot evaluation.
