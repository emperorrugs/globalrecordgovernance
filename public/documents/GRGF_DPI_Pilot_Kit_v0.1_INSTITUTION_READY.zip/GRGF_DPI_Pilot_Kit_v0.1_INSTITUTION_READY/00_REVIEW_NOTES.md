# Review Notes (What was fixed)

## Fixes applied in this pack
- Added a clear Pilot Evaluation Plan (PDF)
- Added an API Contract document (PDF) with the correct endpoints for Pilot Node v0.1
- Updated the Python test CLI to use /login + /submit_event and support the hosted pilot URL
- Updated the verifier app prototypes to use the correct /verify/{record_id} endpoint and include a login flow
- Re-labeled the enterprise Docker ZIP as a non-runnable skeleton and removed unsafe database allow-list defaults

## What remains intentionally pilot-stage
- The full enterprise (OPA + portal + merkle proofs) implementation is not provided here.
- Production hardening (independent audit, rate limiting, advanced monitoring) is planned and must be completed before sovereign deployment.
