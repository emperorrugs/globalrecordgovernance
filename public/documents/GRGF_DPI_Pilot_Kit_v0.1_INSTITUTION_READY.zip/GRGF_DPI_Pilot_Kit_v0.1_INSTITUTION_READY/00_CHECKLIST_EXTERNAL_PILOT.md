# External Pilot Checklist (Institution-Ready)

Use this checklist before sending the kit to external stakeholders.

## Credibility
- [ ] Public site includes: problem statement, architecture, trust center, pilot evaluation, controlled access
- [ ] Clear version registry exists
- [ ] Clear limitations are stated (pilot stage)

## Technical
- [ ] API contract document matches the running service
- [ ] Demo flow is tested end-to-end (login → submit → verify)
- [ ] No public database exposure
- [ ] Swagger/docs are disabled in production (except controlled setup windows)

## Governance
- [ ] Access is controlled (manual issuance)
- [ ] Pilot KPIs and timeline are defined
- [ ] Evaluation report template is ready

## Security
- [ ] No secrets in repos
- [ ] HTTPS everywhere
- [ ] Least privilege roles enforced
