# GRGF DPI Pilot Kit — Start Here (v0.1)

**Date:** February 11, 2026  
**Purpose:** This kit helps stakeholders evaluate GRGF in a controlled, pilot-stage setting.

## What to open first (non-technical)
1) **Pilot Evaluation Plan (PDF)** → explains scope, KPIs, timeline  
2) **Slide Deck (PDF)** → executive overview  
3) **Walkthrough (PDF)** → technical narrative

## If your team wants to test the system (technical)
- Use the **Local Docker Stack** (folder: `03_Code_Reference/00_Pilot_Node_Local_Docker/`)
- Or use the hosted pilot backend (if access is granted)

## Key documents
- `00_Pilot/GRGF_Pilot_Evaluation_Plan_v0.1.pdf`
- `00_Pilot/GRGF_API_Contract_v0.1.pdf`

## IMPORTANT (pilot discipline)
- This kit is for **evaluation** only.
- Do not treat modeled results as certified outcomes.
- Do not store personal data; use synthetic or pseudonymized scenarios.

## Controlled Access
Pilot access is issued manually (no public signups).  
If you received this kit, you are part of a controlled evaluation pathway.

