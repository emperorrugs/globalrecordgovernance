# API Addendum (Pilot Node v0.1)

If any older documents or prototypes reference endpoints like `/events` or `/api/verify`,
use the **official Pilot Node v0.1 contract** instead:

- POST /create_user
- POST /login
- POST /submit_event
- GET  /verify/{record_id}
- GET  /health

See: `00_Pilot/GRGF_API_Contract_v0.1.pdf`
