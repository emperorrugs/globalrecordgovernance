# GRGF Pilot Node — Local Docker Stack (v0.1)

This folder provides a **minimal runnable** local stack for pilot demonstrations:

- FastAPI backend (policy evaluation + hash-chained ledger)
- PostgreSQL database

## 1) Start (one command)

```bash
docker-compose up --build
```

## 2) Open API Docs

```text
http://localhost:8000/docs
```

## 3) Create a user (pilot setup)

POST /create_user
```json
{ "username": "admin", "password": "admin123", "role": "admin" }
```

## 4) Login

POST /login → copy access_token

## 5) Submit Event

POST /submit_event with header:
Authorization: Bearer <token>

Use authority = AUTHORIZED_ROLE to allow.

## Notes
This is a **pilot stack**, not production hardened. For managed databases (e.g., Render), add `?sslmode=require` in DATABASE_URL.
